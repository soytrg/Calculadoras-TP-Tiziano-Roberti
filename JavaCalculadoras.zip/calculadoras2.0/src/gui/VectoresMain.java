package gui;
import main.VectoresLogica;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

import javax.swing.JTextField;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.ImageIcon;

public class VectoresMain extends JFrame {
	double a, b, c, d, E, f, escalarR2 = 0, escalarR3 = 0, R2resSuma1, R2resSuma2, R2resResta1, R2resResta2, R2resMxEscalar1, R2resMxEscalar2,
	R2resProdE1, R2resProdE2, resultadoR2PVE, R3resSuma1, R3resSuma2, R3resSuma3, R3resResta1, R3resResta2, R3resResta3,
	R3resMxEscalar1, R3resMxEscalar2, R3resMxEscalar3, R3resProdE1, R3resProdE2, R3resProdE3, resultado1R3PV, resultado2R3PV, resultado3R3PV;
	
	int segundoterminoR2 = 0, modoEscalarR2 = 0, vaciarR2 = 0, modoSumaR2 = 0, modoRestaR2 = 0, modoNormalR2 = 0, modoProdEscalarR2 = 0,
	modoProdVectorial = 0, segundoterminoR3 = 0, modoEscalarR3 = 0, vaciarR3 = 0, modoSumaR3 = 0, modoRestaR3 = 0, modoNormalR3 = 0, modoProdEscalarR3 = 0,
	cont = 0, modoR3 = 0, contpunto = 0, habilitado = 0;
	
	String aMostrar = null, bMostrar = null, cMostrar = null, dMostrar = null, eMostrar = null, fMostrar = null, escalarMostrarR2 = null, escalarMostrarR3 = null;
	
	boolean capturandoSegundoVector, capturandoSegundoVector1;
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNumero1R2;
	private JTextField txtNumero2R2;
	JPanel panelBotones = new JPanel();
	JPanel panelResultadosR2 = new JPanel();
	JPanel panelTituloR2 = new JPanel();
	JPanel panelTituloR3 = new JPanel();
	JButton btnSeleccionR2 = new JButton("R2");
	JButton btnSeleccionR3 = new JButton("R3");
	JButton btnNum7 = new JButton("7");
	JButton btnNum8 = new JButton("8");
	JButton btnNum9 = new JButton("9");
	JButton btnNum4 = new JButton("4");
	JButton btnNum5 = new JButton("5");
	JButton btnNum6 = new JButton("6");
	JButton btnNum1 = new JButton("1");
	JButton btnNum2 = new JButton("2");
	JButton btnNum3 = new JButton("3");
	JButton btnNegativePositive = new JButton("+/-");
	JButton btnNum0 = new JButton("0");
	JButton btnComa = new JButton(".");
	JButton btnClear = new JButton("C");
	JButton btnDel = new JButton("DEL");
	JButton btnResultadoFinalR2 = new JButton("=");
	JButton btnDivideComponentes = new JButton();
	private final JPanel panelEscalarR2 = new JPanel();
	private final JTextField txtEscalarR2 = new JTextField();
	private final JPanel panelResultadosR3 = new JPanel();
	private final JTextField txtNumero1R3 = new JTextField();
	private final JTextField txtNumero2R3 = new JTextField();
	private final JLabel lblParentesis_1 = new JLabel("(");
	private final JLabel lblParentesis2_1 = new JLabel(")");
	private final JLabel lblComa_1 = new JLabel(",");
	private final JTextField txtNumero3R3 = new JTextField();
	private final JLabel lblComa_1_1 = new JLabel(",");
	private final JPanel panelEscalarR3 = new JPanel();
	private final JTextField txtEscalarR3 = new JTextField();
	private static final int ANIMATION_DURATION = 250; // Duración de la animación en milisegundos
    private static final int ANIMATION_DELAY = 20; // Retraso entre cada paso de la animación en milisegundos
	JLabel lblCC = new JLabel("");
	JLabel lblCCR3 = new JLabel("");
	JLabel lblCCE = new JLabel("");
	JLabel lblCCER3 = new JLabel("");
	private final JButton btnProdVectorial = new JButton();
	private final JPanel panelOperaciones = new JPanel();
	private final JButton btnSumaR2 = new JButton("+");
	private final JButton btnRestaR2 = new JButton("-");
	private final JButton btnMultiplicarR2 = new JButton();
	private final JButton btnMultiplicarEscalarR2 = new JButton();
	Border border = new LineBorder(new Color(0, 220, 235), 2, true); // Color rojo, grosor 2, redondeado

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VectoresMain frame = new VectoresMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VectoresMain() {
        UIManager.put("Button.disabledText", new Color(120,120,120));
		desactivarBotonesOperaciones();
		btnNegativePositive.setEnabled(false);
		btnDivideComponentes.setEnabled(false);
		setResizable(false);
		setFont(new Font("Segoe UI", Font.PLAIN, 20));
		setTitle("Calculadora Vectores");
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 600, 700);
		setLocationRelativeTo(null);
		
		contentPane = new JPanel();
		contentPane.setBackground(new Color(51, 51, 51));
		contentPane.setForeground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		panelResultadosR2();
		
		panelTituloR2.setBackground(new Color(51, 51, 51));
		panelTituloR2.setLayout(null);
		panelTituloR2.setBounds(10, 10, 564, 39);
		contentPane.add(panelTituloR2);
		
		JLabel lblTituloR2 = new JLabel("R2");
		lblTituloR2.setForeground(new Color(255, 255, 255));
		lblTituloR2.setBackground(new Color(51, 51, 51));
		lblTituloR2.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		lblTituloR2.setHorizontalAlignment(SwingConstants.CENTER);
		lblTituloR2.setBounds(10, 11, 544, 23);
		panelTituloR2.add(lblTituloR2);
		
		panelSeleccion();
		
		panelTituloR3.setBackground(new Color(51, 51, 51));
		panelTituloR3.setLayout(null);
		panelTituloR3.setBounds(10, 10, 564, 39);
		contentPane.add(panelTituloR3);
		
		JLabel lblTituloR3 = new JLabel("R3");
		lblTituloR3.setBackground(new Color(51, 51, 51));
		lblTituloR3.setForeground(new Color(255, 255, 255));
		lblTituloR3.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		lblTituloR3.setHorizontalAlignment(SwingConstants.CENTER);
		lblTituloR3.setBounds(10, 11, 544, 23);
		panelTituloR3.add(lblTituloR3);
		
		panelBotones();
	}
	private void panelSeleccion()
	{
		JPanel panelSeleccion = new JPanel();
		panelSeleccion.setBackground(new Color(0, 150, 255));
		panelSeleccion.setBounds(90, 177, 399, 90);
		contentPane.add(panelSeleccion);
		panelSeleccion.setLayout(new GridLayout(1, 0, 0, 0));
		
		btnSeleccionR2.setEnabled(false);
		panelTituloR3.setVisible(false);
		panelEscalarR2.setVisible(false);
		panelEscalarR3.setVisible(false);
		panelResultadosR3.setVisible(false);
		btnSeleccionR2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnProdVectorial.setVisible(false);
				panelOperaciones.remove(btnProdVectorial);
				a = 0;
				b = 0;
				c = 0;
				d = 0;
				E = 0;
				f = 0;
				txtNumero1R3.setText(null);
				txtNumero2R3.setText(null);
				txtNumero3R3.setText(null);
				txtEscalarR3.setText(null);
				btnSeleccionR2.setEnabled(false);
				btnSeleccionR3.setEnabled(true);
				modoR3 = 0;
				modoSumaR2 = 0;
				modoSumaR3 = 0;
				modoRestaR2 = 0;
				modoRestaR3 = 0;
				modoProdEscalarR2 = 0;
				modoProdEscalarR3 = 0;
				modoEscalarR2 = 0;
				modoEscalarR3 = 0;
				modoProdVectorial = 0;
				panelResultadosR2.setVisible(true);
				panelTituloR2.setVisible(true);
				panelTituloR3.setVisible(false);
				panelEscalarR3.setVisible(false);
				panelResultadosR3.setVisible(false);
				btnDivideComponentes.setIcon(new ImageIcon(VectoresMain.class.getResource("/img/divideR2.png")));
				btnDivideComponentes.setDisabledIcon(new ImageIcon(VectoresMain.class.getResource("/img/divideR2Disabled.png")));
				lblCCR3.setText("");
				lblCCR3.setVisible(false);
				lblCC.setText("");
				lblCC.setVisible(false);
				lblCCE.setText("");
				lblCCE.setVisible(false);
				lblCCER3.setText("");
				lblCCER3.setVisible(false);
				btnDivideComponentes.setEnabled(false);
				btnNegativePositive.setEnabled(false);
				btnClear.setEnabled(false);
				btnDel.setEnabled(false);
				btnComa.setEnabled(false);
				segundoterminoR2 = 0;
				segundoterminoR3 = 0;
				desactivarBotonesOperaciones();
				activarBotonesFunciones();
				txtNumero1R2.setBorder(border);
				txtNumero2R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
			}
		});
		btnSeleccionR2.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btnSeleccionR2.setToolTipText("Selecciona el modo de vectores R2");
		btnSeleccionR2.setForeground(new Color(255, 255, 255));
		btnSeleccionR2.setBackground(new Color(0, 150, 255));
		panelSeleccion.add(btnSeleccionR2);
        hover(btnSeleccionR2);
		btnSeleccionR3.setToolTipText("Selecciona el modo de vectores en R3");
		
		btnSeleccionR3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnProdVectorial.setVisible(true);
				panelOperaciones.add(btnProdVectorial);
				a = 0;
				b = 0;
				c = 0;
				d = 0;
				E = 0;
				f = 0;
				txtNumero1R2.setText(null);
				txtNumero2R2.setText(null);
				txtEscalarR2.setText(null);
				btnSeleccionR3.setEnabled(false);
				btnSeleccionR2.setEnabled(true);
				modoR3 = 1;
				modoSumaR2 = 0;
				modoSumaR3 = 0;
				modoRestaR2 = 0;
				modoRestaR3 = 0;
				modoProdEscalarR2 = 0;
				modoProdEscalarR3 = 0;
				modoEscalarR2 = 0;
				modoEscalarR3 = 0;
				modoProdVectorial = 0;
				panelResultadosR2.setVisible(false);
				panelTituloR2.setVisible(false);
				panelTituloR3.setVisible(true);
				panelEscalarR2.setVisible(false);
				panelResultadosR3.setVisible(true);
				btnDivideComponentes.setIcon(new ImageIcon(VectoresMain.class.getResource("/img/divideR3.png")));
				btnDivideComponentes.setDisabledIcon(new ImageIcon(VectoresMain.class.getResource("/img/divideR3Disabled.png")));
				lblCCR3.setText("");
				lblCCR3.setVisible(false);
				lblCC.setText("");
				lblCC.setVisible(false);
				lblCCE.setText("");
				lblCCE.setVisible(false);
				lblCCER3.setText("");
				lblCCER3.setVisible(false);
				btnDivideComponentes.setEnabled(false);
				btnNegativePositive.setEnabled(false);
				btnClear.setEnabled(false);
				btnDel.setEnabled(false);
				btnComa.setEnabled(false);
				segundoterminoR2 = 0;
				segundoterminoR3 = 0;
				desactivarBotonesOperaciones();
				activarBotonesFunciones();
				txtNumero1R3.setBorder(border);
				txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
				txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
			}
		});
		btnSeleccionR3.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btnSeleccionR3.setForeground(new Color(255, 255, 255));
		btnSeleccionR3.setBackground(new Color(0, 150, 255));
		panelSeleccion.add(btnSeleccionR3);
		hover(btnSeleccionR3);
	}
	private void panelResultadosR2()
	{
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnVolver.setForeground(new Color(255, 255, 255));
		btnVolver.setBackground(new Color(77, 77, 77));
		btnVolver.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnVolver.setBounds(0, 0, 79, 27);
		hover(btnVolver);
		contentPane.add(btnVolver);
		
		panelResultadosR2.setForeground(new Color(255, 255, 255));
		panelResultadosR2.setBackground(new Color(51, 51, 51));
		panelResultadosR2.setLayout(null);
		panelResultadosR2.setBounds(10, 60, 564, 106);
		contentPane.add(panelResultadosR2);
		lblCC.setHorizontalAlignment(SwingConstants.CENTER);
		lblCC.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		lblCC.setVisible(false);
		lblCC.setForeground(new Color(128, 128, 128));
		lblCC.setBounds(0, 0, 564, 18);
		panelResultadosR2.add(lblCC);
		
		txtNumero1R2 = new JTextField();
		txtNumero1R2.setBorder(border);
		txtNumero1R2.setForeground(new Color(255, 255, 255));
		txtNumero1R2.setBackground(new Color(51, 51, 51));
		txtNumero1R2.setHorizontalAlignment(SwingConstants.CENTER);
		txtNumero1R2.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		txtNumero1R2.setEditable(false);
		txtNumero1R2.setColumns(10);
		txtNumero1R2.setBounds(80, 22, 127, 73);
		panelResultadosR2.add(txtNumero1R2);
		
		txtNumero2R2 = new JTextField();
		txtNumero2R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
		txtNumero2R2.setForeground(new Color(255, 255, 255));
		txtNumero2R2.setBackground(new Color(51, 51, 51));
		txtNumero2R2.setHorizontalAlignment(SwingConstants.CENTER);
		txtNumero2R2.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		txtNumero2R2.setEditable(false);
		txtNumero2R2.setColumns(10);
		txtNumero2R2.setBounds(352, 22, 127, 73);
		panelResultadosR2.add(txtNumero2R2);
		
		JLabel lblParentesis = new JLabel("(");
		lblParentesis.setForeground(new Color(255, 255, 255));
		lblParentesis.setBackground(new Color(0, 0, 0));
		lblParentesis.setFont(new Font("Segoe UI", Font.PLAIN, 50));
		lblParentesis.setBounds(50, 0, 25, 106);
		panelResultadosR2.add(lblParentesis);
		
		JLabel lblParentesis2 = new JLabel(")");
		lblParentesis2.setForeground(new Color(255, 255, 255));
		lblParentesis2.setBackground(new Color(0, 0, 0));
		lblParentesis2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblParentesis2.setFont(new Font("Segoe UI", Font.PLAIN, 50));
		lblParentesis2.setBounds(482, 0, 25, 106);
		panelResultadosR2.add(lblParentesis2);
		
		JLabel lblComa = new JLabel(",");
		lblComa.setForeground(new Color(255, 255, 255));
		lblComa.setBackground(new Color(0, 0, 0));
		lblComa.setHorizontalAlignment(SwingConstants.CENTER);
		lblComa.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		lblComa.setBounds(260, 52, 46, 43);
		panelResultadosR2.add(lblComa);
	}
	private void panelBotones()
	{
		panelBotones.setBackground(new Color(51, 51, 51));
		panelBotones.setBounds(90, 278, 399, 295);
		contentPane.add(panelBotones);
		panelBotones.setLayout(new GridLayout(4, 4, 1, 1));
		panelEscalarR2.setBackground(new Color(51, 51, 51));
		panelEscalarR2.setLayout(null);
		panelEscalarR2.setBounds(10, 60, 564, 106);
		
		contentPane.add(panelEscalarR2);
		txtEscalarR2.setBackground(new Color(51, 51, 51));
		txtEscalarR2.setForeground(new Color(255, 255, 255));
		txtEscalarR2.setHorizontalAlignment(SwingConstants.CENTER);
		txtEscalarR2.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		txtEscalarR2.setEditable(false);
		txtEscalarR2.setColumns(10);
		txtEscalarR2.setBounds(226, 23, 102, 72);
		
		panelEscalarR2.add(txtEscalarR2);
		lblCCE.setHorizontalAlignment(SwingConstants.CENTER);
		lblCCE.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		lblCCE.setVisible(false);
		lblCCE.setForeground(new Color(128, 128, 128));
		lblCCE.setBounds(0, 0, 564, 20);
		panelEscalarR2.add(lblCCE);//7
		
		panelResultadosR3.setBackground(new Color(51, 51, 51));
		panelResultadosR3.setLayout(null);
		panelResultadosR3.setBounds(10, 60, 564, 106);
		
		lblCCR3.setHorizontalAlignment(SwingConstants.CENTER);
		lblCCR3.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		lblCCR3.setVisible(false);
		lblCCR3.setForeground(new Color(128, 128, 128));
		lblCCR3.setBounds(0, 0, 564, 18);
		panelResultadosR3.add(lblCCR3);
		
		contentPane.add(panelResultadosR3);
		txtNumero1R3.setBorder(border);
		txtNumero1R3.setForeground(new Color(255, 255, 255));
		txtNumero1R3.setBackground(new Color(51, 51, 51));
		txtNumero1R3.setHorizontalAlignment(SwingConstants.CENTER);
		txtNumero1R3.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		txtNumero1R3.setEditable(false);
		txtNumero1R3.setColumns(10);
		txtNumero1R3.setBounds(81, 22, 90, 73);
		
		panelResultadosR3.add(txtNumero1R3);
		txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
		txtNumero2R3.setForeground(new Color(255, 255, 255));
		txtNumero2R3.setBackground(new Color(51, 51, 51));
		txtNumero2R3.setHorizontalAlignment(SwingConstants.CENTER);
		txtNumero2R3.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		txtNumero2R3.setEditable(false);
		txtNumero2R3.setColumns(10);
		txtNumero2R3.setBounds(233, 22, 90, 73);
		
		panelResultadosR3.add(txtNumero2R3);
		lblParentesis_1.setBackground(new Color(51, 51, 51));
		lblParentesis_1.setForeground(new Color(255, 255, 255));
		lblParentesis_1.setFont(new Font("Segoe UI", Font.PLAIN, 50));
		lblParentesis_1.setBounds(50, 0, 21, 106);
		
		panelResultadosR3.add(lblParentesis_1);
		lblParentesis2_1.setBackground(new Color(51, 51, 51));
		lblParentesis2_1.setForeground(new Color(255, 255, 255));
		lblParentesis2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblParentesis2_1.setFont(new Font("Segoe UI", Font.PLAIN, 50));
		lblParentesis2_1.setBounds(481, 0, 26, 106);
		
		panelResultadosR3.add(lblParentesis2_1);
		lblComa_1.setBackground(new Color(51, 51, 51));
		lblComa_1.setForeground(new Color(255, 255, 255));
		lblComa_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblComa_1.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		lblComa_1.setBounds(169, 29, 46, 43);
		
		panelResultadosR3.add(lblComa_1);
		txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
		txtNumero3R3.setForeground(new Color(255, 255, 255));
		txtNumero3R3.setBackground(new Color(51, 51, 51));
		txtNumero3R3.setHorizontalAlignment(SwingConstants.CENTER);
		txtNumero3R3.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		txtNumero3R3.setEditable(false);
		txtNumero3R3.setColumns(10);
		txtNumero3R3.setBounds(389, 22, 90, 73);
		
		panelResultadosR3.add(txtNumero3R3);
		lblComa_1_1.setForeground(new Color(255, 255, 255));
		lblComa_1_1.setBackground(new Color(51, 51, 51));
		lblComa_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblComa_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		lblComa_1_1.setBounds(342, 29, 49, 43);
		
		panelResultadosR3.add(lblComa_1_1);
		panelEscalarR3.setLayout(null);
		panelEscalarR3.setBackground(new Color(51, 51, 51));
		panelEscalarR3.setBounds(10, 60, 564, 106);
		
		contentPane.add(panelEscalarR3);
		txtEscalarR3.setHorizontalAlignment(SwingConstants.CENTER);
		txtEscalarR3.setForeground(Color.WHITE);
		txtEscalarR3.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		txtEscalarR3.setEditable(false);
		txtEscalarR3.setColumns(10);
		txtEscalarR3.setBackground(new Color(51, 51, 51));
		txtEscalarR3.setBounds(237, 22, 85, 73);
		
		panelEscalarR3.add(txtEscalarR3);
		
		lblCCER3.setHorizontalAlignment(SwingConstants.CENTER);
		lblCCER3.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		lblCCER3.setVisible(false);
		lblCCER3.setForeground(new Color(128, 128, 128));
		lblCCER3.setBounds(0, 0, 564, 20);
		panelEscalarR3.add(lblCCER3);//7
		
		panelOperaciones.setBackground(new Color(51, 51, 51));
		panelOperaciones.setBounds(90, 574, 399, 76);
		
		panelBotonesFunciones();
		panelBotonesOperaciones();
		
	}
	private void panelBotonesFunciones()
	{
		btnNum7.setForeground(new Color(255, 255, 255));
		btnNum7.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnNum7.setBackground(new Color(77, 77, 77));
		panelBotones.add(btnNum7);
		insertarnum(btnNum7);
		btnNum7.setBorder(null);
        hover(btnNum7);

		btnNum8.setForeground(new Color(255, 255, 255));
		btnNum8.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnNum8.setBackground(new Color(77, 77, 77));
		panelBotones.add(btnNum8);
		insertarnum(btnNum8);
        hover(btnNum8);

		btnNum9.setForeground(new Color(255, 255, 255));
		btnNum9.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnNum9.setBackground(new Color(77, 77, 77));
		panelBotones.add(btnNum9);
		insertarnum(btnNum9);
        hover(btnNum9);

		btnClear.setForeground(new Color(255, 255, 255));
		btnClear.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnClear.setBackground(new Color(0, 150, 255));
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(modoR3 == 0)
				{
					activarBotonesFunciones();
					desactivarBotonesOperaciones();
					btnDivideComponentes.setEnabled(false);
					btnNegativePositive.setEnabled(false);
					btnClear.setEnabled(false);
					btnDel.setEnabled(false);
					txtNumero1R2.setText(null);
					txtNumero2R2.setText(null);
					txtEscalarR2.setText(null);
					panelResultadosR2.setVisible(true);
					panelEscalarR2.setVisible(false);
					segundoterminoR2 = 0;
					if(vaciarR2 == 1)
					{
						lblCC.setText("");
						lblCC.setVisible(false);	
					}
					vaciarR2 = 0;
					btnComa.setEnabled(false);
					txtNumero1R2.setBorder(border);
					txtNumero2R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
				}
				if(modoR3 == 1)
				{
					activarBotonesFunciones();
					desactivarBotonesOperaciones();
					btnDivideComponentes.setEnabled(false);
					btnNegativePositive.setEnabled(false);
					btnClear.setEnabled(false);
					btnDel.setEnabled(false);
					txtNumero1R3.setText(null);
					txtNumero2R3.setText(null);
					txtNumero3R3.setText(null);
					txtEscalarR3.setText(null);
					panelResultadosR3.setVisible(true);
					panelEscalarR3.setVisible(false);
					segundoterminoR3 = 0;
					if(vaciarR3 == 1)
					{
						lblCCR3.setText("");
						lblCCR3.setVisible(false);	
					}
					vaciarR3 = 0;
					btnComa.setEnabled(false);
					txtNumero1R3.setBorder(border);
					txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
				}
			}
		});
		panelBotones.add(btnClear);
        hover(btnClear);
		
		btnNum4.setForeground(new Color(255, 255, 255));
		btnNum4.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnNum4.setBackground(new Color(77, 77, 77));
		panelBotones.add(btnNum4);
		insertarnum(btnNum4);
        hover(btnNum4);

		btnNum5.setForeground(new Color(255, 255, 255));
		btnNum5.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnNum5.setBackground(new Color(77, 77, 77));
		panelBotones.add(btnNum5);
		insertarnum(btnNum5);
        hover(btnNum5);

		btnNum6.setForeground(new Color(255, 255, 255));
		btnNum6.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnNum6.setBackground(new Color(77, 77, 77));
		panelBotones.add(btnNum6);
		insertarnum(btnNum6);
        hover(btnNum6);

		btnDel.setForeground(new Color(255, 255, 255));
		btnDel.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnDel.setBackground(new Color(0, 150, 255));
		panelBotones.add(btnDel);
        hover(btnDel);
		btnDel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
		    {
				if(modoR3 == 0)
				{
					if(segundoterminoR2 == 0)
					{
						if(txtNumero1R2.getText().length() +1 > 0)
				        {
				        	txtNumero1R2.setText(txtNumero1R2.getText().substring(0, txtNumero1R2.getText().length() - 1));
				        	if(txtNumero1R2.getText().contains("-") && txtNumero1R2.getText().length() < 2)
				        	{
				        		txtNumero1R2.setText(null);
				        	}
				        }
						
				        if(txtNumero1R2.getText().length() == 0)
				        {
				            desactivarBotonesOperaciones();
				            btnDivideComponentes.setEnabled(false);
				            btnNegativePositive.setEnabled(false);
							btnComa.setEnabled(false);
				        }
					}
					if(segundoterminoR2 == 1)
					{
						if(txtNumero2R2.getText().length() +1 > 0)
				        {
				        	txtNumero2R2.setText(txtNumero2R2.getText().substring(0, txtNumero2R2.getText().length() - 1));
				        	if(txtNumero2R2.getText().contains("-") && txtNumero2R2.getText().length() < 2)
				        	{
				        		txtNumero2R2.setText(null);
				        	}
				        }

				        if(txtNumero2R2.getText().length() == 0)
				        {
				            desactivarBotonesOperaciones();
				            btnDivideComponentes.setEnabled(false);
				            btnNegativePositive.setEnabled(false);
				            btnComa.setEnabled(false);
				        }
					}
					if(modoEscalarR2 == 1)
					{
						if(txtEscalarR2.getText().length() +1 > 0)
						{
							txtEscalarR2.setText(txtEscalarR2.getText().substring(0, txtEscalarR2.getText().length() - 1));
							if(txtEscalarR2.getText().contains("-") && txtEscalarR2.getText().length() < 2)
				        	{
				        		txtEscalarR2.setText(null);
				        	}
						}
						
						if(txtEscalarR2.getText().length() == 0)
				        {
				            desactivarBotonesOperaciones();
				            btnDivideComponentes.setEnabled(false);
				            btnNegativePositive.setEnabled(false);
				            btnComa.setEnabled(false);
				        }
					}
					
					if(vaciarR2 == 1)
					{
						txtNumero1R2.setText(null);
						txtNumero2R2.setText(null);
						txtEscalarR2.setText(null);
						escalarR2 = 0;
						a = 0;
						b = 0;
						c = 0;
						d = 0;
						R2resSuma1 = 0;
						R2resSuma2 = 0;
						R2resResta1 = 0;
						R2resResta2 = 0;
						R2resMxEscalar1 = 0;
						R2resMxEscalar2 = 0;
						R2resProdE1 = 0;
						R2resProdE2 = 0;
						segundoterminoR2 = 0;
						vaciarR2 = 0;
						btnComa.setEnabled(false);
						panelEscalarR2.setVisible(false);
						panelResultadosR2.setVisible(true);
						lblCC.setText("");
						lblCC.setVisible(false);
						btnDivideComponentes.setEnabled(false);
			            btnNegativePositive.setEnabled(false);
					}
				}
				if(modoR3 == 1)
				{
					if(segundoterminoR3 == 0)
					{
						if(txtNumero1R3.getText().length() +1 > 0)
				        {
				        	txtNumero1R3.setText(txtNumero1R3.getText().substring(0, txtNumero1R3.getText().length() - 1));
				        	if(txtNumero1R3.getText().contains("-") && txtNumero1R3.getText().length() < 2)
				        	{
				        		txtNumero1R3.setText(null);
				        	}
				        }

				        if(txtNumero1R3.getText().length() == 0)
				        {
				            desactivarBotonesOperaciones();
				            btnDivideComponentes.setEnabled(false);
				            btnNegativePositive.setEnabled(false);
				            btnComa.setEnabled(false);
				        }
					}
					if(segundoterminoR3 == 1)
					{
						if(txtNumero2R3.getText().length() +1 > 0)
				        {
				        	txtNumero2R3.setText(txtNumero2R3.getText().substring(0, txtNumero2R3.getText().length() - 1));
				        	if(txtNumero2R3.getText().contains("-") && txtNumero2R3.getText().length() < 2)
				        	{
				        		txtNumero2R3.setText(null);
				        	}
				        }

				        if(txtNumero2R3.getText().length() == 0)
				        {
				            desactivarBotonesOperaciones();
				            btnDivideComponentes.setEnabled(false);
				            btnNegativePositive.setEnabled(false);
				            btnComa.setEnabled(false);
				        }
					}
					if(segundoterminoR3 == 2)
					{
						if(txtNumero3R3.getText().length() +1 > 0)
				        {
				        	txtNumero3R3.setText(txtNumero3R3.getText().substring(0, txtNumero3R3.getText().length() - 1));
				        	if(txtNumero3R3.getText().contains("-") && txtNumero3R3.getText().length() < 2)
				        	{
				        		txtNumero3R3.setText(null);
				        	}
				        }

				        if(txtNumero3R3.getText().length() == 0)
				        {
				            desactivarBotonesOperaciones();
				            btnDivideComponentes.setEnabled(false);
				            btnNegativePositive.setEnabled(false);
				            btnComa.setEnabled(false);
				        }
					}
					if(modoEscalarR3 == 1)
					{
						if(txtEscalarR3.getText().length() +1 > 0)
						{
							txtEscalarR3.setText(txtEscalarR3.getText().substring(0, txtEscalarR3.getText().length() - 1));
							if(txtEscalarR3.getText().contains("-") && txtEscalarR3.getText().length() < 2)
				        	{
				        		txtEscalarR3.setText(null);
				        	}
						}
						
						if(txtEscalarR3.getText().length() == 0)
				        {
				            desactivarBotonesOperaciones();
				            btnDivideComponentes.setEnabled(false);
				            btnNegativePositive.setEnabled(false);
				            btnComa.setEnabled(false);
				        }
					}
					
					if(vaciarR3 == 1)
					{
						txtNumero1R3.setText(null);
						txtNumero2R3.setText(null);
						txtNumero3R3.setText(null);
						txtEscalarR3.setText(null);
						escalarR3 = 0;
						a = 0;
						b = 0;
						c = 0;
						d = 0;
						E = 0;
						f = 0;
						R3resSuma1 = 0;
						R3resSuma2 = 0;
						R3resSuma3 = 0;
						R3resResta1 = 0;
						R3resResta2 = 0;
						R3resResta3 = 0;
						R3resMxEscalar1 = 0;
						R3resMxEscalar2 = 0;
						R3resMxEscalar3 = 0;
						R3resProdE1 = 0;
						R3resProdE2 = 0;
						R3resProdE3 = 0;
						resultado1R3PV = 0;
						resultado2R3PV = 0;
						resultado3R3PV = 0;
						segundoterminoR3 = 0;
						vaciarR3 = 0;
						btnComa.setEnabled(false);
						panelEscalarR3.setVisible(false);
						panelResultadosR3.setVisible(true);
						lblCCR3.setText("");
						lblCCR3.setVisible(false);
						btnDivideComponentes.setEnabled(false);
			            btnNegativePositive.setEnabled(false);
					}
				}
		    }
		});
		
		btnNum1.setForeground(new Color(255, 255, 255));
		btnNum1.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnNum1.setBackground(new Color(77, 77, 77));
		panelBotones.add(btnNum1);
		insertarnum(btnNum1);
        hover(btnNum1);

		btnNum2.setForeground(new Color(255, 255, 255));
		btnNum2.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnNum2.setBackground(new Color(77, 77, 77));
		panelBotones.add(btnNum2);
		insertarnum(btnNum2);
        hover(btnNum2);

		btnNum3.setForeground(new Color(255, 255, 255));
		btnNum3.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnNum3.setBackground(new Color(77, 77, 77));
		panelBotones.add(btnNum3);
		insertarnum(btnNum3);
        hover(btnNum3);

		btnResultadoFinalR2.setForeground(new Color(255, 255, 255));
		btnResultadoFinalR2.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnResultadoFinalR2.setBackground(new Color(0, 175, 255));
		panelBotones.add(btnResultadoFinalR2);
        hover(btnResultadoFinalR2);
		btnResultadoFinalR2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(modoR3 == 0)
				{
					if(modoEscalarR2 == 1)
					{
						String numeroingresado = txtEscalarR2.getText();
						double temp = Double.parseDouble(numeroingresado);
						escalarR2 = temp;
						temp = 0;
						escalarMostrarR2 = mostrarSinDecimal(numeroingresado, escalarR2, escalarMostrarR2);
						double[] resultados = new double[2];
			            VectoresLogica.R2MultEscalar(a, b, escalarR2, resultados);

			            R2resMxEscalar1 = resultados[0];
			            R2resMxEscalar2 = resultados[1];
			            
			            String res = mostrarSinDecimal2(R2resMxEscalar1, 4);
			            String res1 = mostrarSinDecimal2(R2resMxEscalar2, 4);
			            
						panelEscalarR2.setVisible(false);
						panelResultadosR2.setVisible(true);
						txtNumero1R2.setText(res);
						txtNumero2R2.setText(res1);
						vaciarR2 = 1;
						desactivarBotonesOperaciones();
					    btnClear.setEnabled(true);
					    btnDivideComponentes.setEnabled(false);
					    modoEscalarR2 = 0;
					    lblCC.setText("("+aMostrar+", "+bMostrar+") * "+escalarMostrarR2);
						lblCC.setVisible(true);
						desactivarBotonesFunciones();
		            	txtNumero2R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero1R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					}
					if(modoSumaR2 == 1)
					{
						String numeroingresado = txtNumero2R2.getText();
						double temp = Double.parseDouble(numeroingresado);
						d = temp;
						temp = 0;
						dMostrar = mostrarSinDecimal(numeroingresado, d, dMostrar);
						double[] resultadosR2S = new double[2];
						VectoresLogica.R2suma(a, b, c, d, resultadosR2S);
						
						R2resSuma1 = resultadosR2S[0];
						R2resSuma2 = resultadosR2S[1];
						
						String res = mostrarSinDecimal2(R2resSuma1, 4);
			            String res1 = mostrarSinDecimal2(R2resSuma2, 4);
						txtNumero1R2.setText(res);
						txtNumero2R2.setText(res1);
						vaciarR2 = 1;
						desactivarBotonesOperaciones();
						btnClear.setEnabled(true);
					    btnDivideComponentes.setEnabled(false);
					    modoSumaR2 = 0;
					    lblCC.setText("("+aMostrar+", "+bMostrar+") + ("+cMostrar+", "+dMostrar+")");
						lblCC.setVisible(true);
						desactivarBotonesFunciones();
						txtNumero2R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero1R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					}
					if(modoRestaR2 == 1)
					{
						String numeroingresado = txtNumero2R2.getText();
						double temp = Double.parseDouble(numeroingresado);
						d = temp;
						temp = 0;
						dMostrar = mostrarSinDecimal(numeroingresado, d, dMostrar);
						double[] resultadosR2R = new double[2];
						VectoresLogica.R2resta(a, b, c, d, resultadosR2R);
						
						R2resResta1 = resultadosR2R[0];
						R2resResta2 = resultadosR2R[1];
						
						String res = mostrarSinDecimal2(R2resResta1, 4);
			            String res1 = mostrarSinDecimal2(R2resResta2, 4);
						txtNumero1R2.setText(res);
						txtNumero2R2.setText(res1);
						vaciarR2 = 1;
						desactivarBotonesOperaciones();
						btnClear.setEnabled(true);
					    btnDivideComponentes.setEnabled(false);
					    modoRestaR2 = 0;
					    lblCC.setText("("+aMostrar+", "+bMostrar+") - ("+cMostrar+", "+dMostrar+")");
						lblCC.setVisible(true);
						desactivarBotonesFunciones();
						txtNumero2R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero1R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					}
					
					if(modoProdEscalarR2 == 1)
					{
						String numeroingresado = txtNumero2R2.getText();
						double temp = Double.parseDouble(numeroingresado);
						d = temp;
						temp = 0;
						dMostrar = mostrarSinDecimal(numeroingresado, d, dMostrar);
						double[] resultadosR2PE = new double[2];
						VectoresLogica.R2ProdEscalar(a, b, c, d, resultadosR2PE);
						
						R2resProdE1 = resultadosR2PE[0];
						R2resProdE2 = resultadosR2PE[1];
						
						String res = mostrarSinDecimal2(R2resProdE1, 4);
			            String res1 = mostrarSinDecimal2(R2resProdE2, 4);
						txtNumero1R2.setText(res);
						txtNumero2R2.setText(res1);
						vaciarR2 = 1;
						desactivarBotonesOperaciones();
						btnClear.setEnabled(true);
					    btnDivideComponentes.setEnabled(false);
						modoProdEscalarR2 = 0;
						lblCC.setText("("+aMostrar+", "+bMostrar+") * ("+cMostrar+", "+dMostrar+")");
						lblCC.setVisible(true);
						desactivarBotonesFunciones();
						txtNumero2R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero1R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					}
				}
				
				if(modoR3 == 1)
				{
					if(modoEscalarR3 == 1)
					{
						String numeroingresado = txtEscalarR3.getText();
						double temp = Double.parseDouble(numeroingresado);
						escalarR3 = temp;
						temp = 0;
						escalarMostrarR3 = mostrarSinDecimal(numeroingresado, escalarR3, escalarMostrarR3);
						double[] resultados = new double[3];
			            VectoresLogica.R3MultEscalar(a, b, c, escalarR3, resultados);

			            R3resMxEscalar1 = resultados[0];
			            R3resMxEscalar2 = resultados[1];
			            R3resMxEscalar3 = resultados[2];
			            
			            String res = mostrarSinDecimal2(R3resMxEscalar1, 4);
			            String res1 = mostrarSinDecimal2(R3resMxEscalar2, 4);
			            String res2 = mostrarSinDecimal2(R3resMxEscalar3, 4);
						panelEscalarR3.setVisible(false);
						panelResultadosR3.setVisible(true);
						txtNumero1R3.setText(res);
						txtNumero2R3.setText(res1);
						txtNumero3R3.setText(res2);
						vaciarR3 = 1;
						desactivarBotonesOperaciones();
						btnClear.setEnabled(true);
					    btnDivideComponentes.setEnabled(false);
					    modoEscalarR3 = 0;
					    lblCCR3.setText("("+aMostrar+", "+bMostrar+", "+cMostrar+") * "+escalarMostrarR3);
						lblCCR3.setVisible(true);
						desactivarBotonesFunciones();
						txtNumero1R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					}
					if(modoSumaR3 == 1)
					{
						String numeroingresado = txtNumero3R3.getText();
						double temp = Double.parseDouble(numeroingresado);
						f = temp;
						temp = 0;
						fMostrar = mostrarSinDecimal(numeroingresado, f, fMostrar);
						double[] resultadosR3S = new double[3];
						VectoresLogica.R3suma(a, b, c, d, E, f, resultadosR3S);
						
						R3resSuma1 = resultadosR3S[0];
						R3resSuma2 = resultadosR3S[1];
						R3resSuma3 = resultadosR3S[2];
						
						String res = mostrarSinDecimal2(R3resSuma1, 4);
			            String res1 = mostrarSinDecimal2(R3resSuma2, 4);
			            String res2 = mostrarSinDecimal2(R3resSuma3, 4);
						txtNumero1R3.setText(res);
						txtNumero2R3.setText(res1);
						txtNumero3R3.setText(res2);
						vaciarR3 = 1;
						desactivarBotonesOperaciones();
						btnClear.setEnabled(true);
					    btnDivideComponentes.setEnabled(false);
					    modoSumaR3 = 0;
					    lblCCR3.setText("("+aMostrar+", "+bMostrar+", "+cMostrar+") + ("+dMostrar+", "+eMostrar+", "+fMostrar+")");
						lblCCR3.setVisible(true);
						desactivarBotonesFunciones();
						txtNumero1R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					}
					if(modoRestaR3 == 1)
					{
						String numeroingresado = txtNumero3R3.getText();
						double temp = Double.parseDouble(numeroingresado);
						f = temp;
						temp = 0;
						fMostrar = mostrarSinDecimal(numeroingresado, f, fMostrar);
						double[] resultadosR3R = new double[3];
						VectoresLogica.R3resta(a, b, c, d, E, f, resultadosR3R);
						
						R3resResta1 = resultadosR3R[0];
						R3resResta2 = resultadosR3R[1];
						R3resResta3 = resultadosR3R[2];
						
						String res = mostrarSinDecimal2(R3resResta1, 4);
			            String res1 = mostrarSinDecimal2(R3resResta2, 4);
			            String res2 = mostrarSinDecimal2(R3resResta3, 4);
						txtNumero1R3.setText(res);
						txtNumero2R3.setText(res1);
						txtNumero3R3.setText(res2);
						vaciarR3 = 1;
						desactivarBotonesOperaciones();
						btnClear.setEnabled(true);
					    btnDivideComponentes.setEnabled(false);
					    modoRestaR3 = 0;
					    lblCCR3.setText("("+aMostrar+", "+bMostrar+", "+cMostrar+") - ("+dMostrar+", "+eMostrar+", "+fMostrar+")");
						lblCCR3.setVisible(true);
						desactivarBotonesFunciones();
						txtNumero1R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					}
					
					if(modoProdVectorial == 1)
					{
						String numeroingresado = txtNumero3R3.getText();
						double temp = Double.parseDouble(numeroingresado);
						f = temp;
						temp = 0;
						fMostrar = mostrarSinDecimal(numeroingresado, f, fMostrar);
						double[] resultado = new double[3];
						VectoresLogica.R3ProdVectorial(a, b, c, d, E, f, resultado);
						
						resultado1R3PV = resultado[0];
						resultado2R3PV = resultado[1];
						resultado3R3PV = resultado[2];
						
						String res = mostrarSinDecimal2(resultado1R3PV, 4);
			            String res1 = mostrarSinDecimal2(resultado2R3PV, 4);
			            String res2 = mostrarSinDecimal2(resultado3R3PV, 4);
						txtNumero1R3.setText(res);
						txtNumero2R3.setText(res1);
						txtNumero3R3.setText(res2);
						vaciarR3 = 1;
						desactivarBotonesOperaciones();
						btnClear.setEnabled(true);
					    btnDivideComponentes.setEnabled(false);
						modoProdVectorial = 0;
						lblCCR3.setText("("+aMostrar+", "+bMostrar+", "+cMostrar+") ^ ("+dMostrar+", "+eMostrar+", "+fMostrar+")");
						lblCCR3.setVisible(true);
						desactivarBotonesFunciones();
						txtNumero1R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					}
					
					if(modoProdEscalarR3 == 1)
					{
						String numeroingresado = txtNumero3R3.getText();
						double temp = Double.parseDouble(numeroingresado);
						f = temp;
						temp = 0;
						fMostrar = mostrarSinDecimal(numeroingresado, f, fMostrar);
						double[] resultadosR3PE = new double[3];
						VectoresLogica.R3ProdEscalar(a, b, c, d, E, f, resultadosR3PE);
						
						R3resProdE1 = resultadosR3PE[0];
						R3resProdE2 = resultadosR3PE[1];
						R3resProdE3 = resultadosR3PE[2];
						
						String res = mostrarSinDecimal2(R3resProdE1, 4);
			            String res1 = mostrarSinDecimal2(R3resProdE2, 4);
			            String res2 = mostrarSinDecimal2(R3resProdE3, 4);
						txtNumero1R3.setText(res);
						txtNumero2R3.setText(res1);
						txtNumero3R3.setText(res2);
						vaciarR3 = 1;
						desactivarBotonesOperaciones();
						btnClear.setEnabled(true);
					    btnDivideComponentes.setEnabled(false);
						modoProdEscalarR3 = 0;
						lblCCR3.setText("("+aMostrar+", "+bMostrar+", "+cMostrar+") * ("+dMostrar+", "+eMostrar+", "+fMostrar+")");
						lblCCR3.setVisible(true);
						desactivarBotonesFunciones();
						txtNumero1R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					}
				}
			}
		});
		
		btnNegativePositive.setForeground(new Color(255, 255, 255));
		btnNegativePositive.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnNegativePositive.setBackground(new Color(77, 77, 77));
		panelBotones.add(btnNegativePositive);
        hover(btnNegativePositive);
		btnNegativePositive.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(modoR3 == 0)
				{
					if(segundoterminoR2 == 0)
					{
						String texto1 = txtNumero1R2.getText();
				        double numero1 = Double.parseDouble(texto1);
				        if (texto1.contains("."))
				        {
				            numero1 = -numero1;
				            txtNumero1R2.setText(String.valueOf(numero1));
				        }
				        else
				        {
				        	DecimalFormat formato = new DecimalFormat("#");
				            numero1 = -numero1;
				            String numeroFormateado = formato.format(numero1);
				            txtNumero1R2.setText(numeroFormateado);
				        }
					}
					if(segundoterminoR2 == 1)
					{
						String texto1 = txtNumero2R2.getText();
				        double numero1 = Double.parseDouble(texto1);
				        if (texto1.contains("."))
				        {
				            numero1 = -numero1;
				            txtNumero2R2.setText(String.valueOf(numero1));
				        }
				        else
				        {
				        	DecimalFormat formato = new DecimalFormat("#");
				            numero1 = -numero1;
				            String numeroFormateado = formato.format(numero1);
				            txtNumero2R2.setText(numeroFormateado);
				        }
					}
					if(modoEscalarR2 == 1)
					{
						String texto1 = txtEscalarR2.getText();
				        double numero1 = Double.parseDouble(texto1);
				        if (texto1.contains("."))
				        {
				            numero1 = -numero1;
				            txtEscalarR2.setText(String.valueOf(numero1));
				        }
				        else
				        {
				        	DecimalFormat formato = new DecimalFormat("#");
				            numero1 = -numero1;
				            String numeroFormateado = formato.format(numero1);
				            txtEscalarR2.setText(numeroFormateado);
				        }
				        modoEscalarR2 = 0;
					}
				}
				
				if(modoR3 == 1)
				{
					if(segundoterminoR3 == 0)
					{
						String texto1 = txtNumero1R3.getText();
				        double numero1 = Double.parseDouble(texto1);
				        if (texto1.contains("."))
				        {
				            numero1 = -numero1;
				            txtNumero1R3.setText(String.valueOf(numero1));
				        }
				        else
				        {
				        	DecimalFormat formato = new DecimalFormat("#");
				            numero1 = -numero1;
				            String numeroFormateado = formato.format(numero1);
				            txtNumero1R3.setText(numeroFormateado);
				        }
					}
					if(segundoterminoR3 == 1)
					{
						String texto1 = txtNumero2R3.getText();
				        double numero1 = Double.parseDouble(texto1);
				        if (texto1.contains("."))
				        {
				            numero1 = -numero1;
				            txtNumero2R3.setText(String.valueOf(numero1));
				        }
				        else
				        {
				        	DecimalFormat formato = new DecimalFormat("#");
				            numero1 = -numero1;
				            String numeroFormateado = formato.format(numero1);
				            txtNumero2R3.setText(numeroFormateado);
				        }
					}
					if(segundoterminoR3 == 2)
					{
						String texto1 = txtNumero3R3.getText();
						double numero1 = Double.parseDouble(texto1);
						if (texto1.contains("."))
				        {
				            numero1 = -numero1;
				            txtNumero3R3.setText(String.valueOf(numero1));
				        }
				        else
				        {
				        	DecimalFormat formato = new DecimalFormat("#");
				            numero1 = -numero1;
				            String numeroFormateado = formato.format(numero1);
				            txtNumero3R3.setText(numeroFormateado);
				        }
					}
					if(modoEscalarR3 == 1)
					{
						String texto1 = txtEscalarR3.getText();
				        double numero1 = Double.parseDouble(texto1);
				        if (texto1.contains("."))
				        {
				            numero1 = -numero1;
				            txtEscalarR3.setText(String.valueOf(numero1));
				        }
				        else
				        {
				        	DecimalFormat formato = new DecimalFormat("#");
				            numero1 = -numero1;
				            String numeroFormateado = formato.format(numero1);
				            txtEscalarR3.setText(numeroFormateado);
				        }
				        modoEscalarR3 = 0;
					}
				}
			}
		});
		
		btnNum0.setForeground(new Color(255, 255, 255));
		btnNum0.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnNum0.setBackground(new Color(77, 77, 77));
		panelBotones.add(btnNum0);
		insertarnum(btnNum0);
        hover(btnNum0);

		btnComa.setForeground(new Color(255, 255, 255));
		btnComa.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnComa.setBackground(new Color(77, 77, 77));
		panelBotones.add(btnComa);
		btnComa.setEnabled(false);
		btnComa.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						if(modoR3 == 0)
						{
							if(txtNumero1R2.getText().length() +1 > 0 || txtNumero2R2.getText().length() +1 > 0 || txtEscalarR2.getText().length() +1 > 0)
							{
								btnDel.setEnabled(true);
								btnClear.setEnabled(true);
							}
							if(txtNumero1R2.getText() == null || txtNumero2R2.getText() == null || txtEscalarR2.getText() == null)
							{
								btnNegativePositive.setEnabled(false);
								btnComa.setEnabled(false);
							}
							if(segundoterminoR2 == 0)
							{
								btnNegativePositive.setEnabled(true);
								btnDivideComponentes.setEnabled(true);
								String ingresenumero = txtNumero1R2.getText() + btnComa.getText();
								txtNumero1R2.setText(ingresenumero);
								ingresenumero = null;
								btnComa.setEnabled(false);
							}
							
							if(segundoterminoR2 == 1)
							{
								if(txtNumero1R2.getText().length() +1 > 0 && txtNumero2R2.getText().length() +1 > 0)
								{
									activarBotonesOperaciones();
									btnResultadoFinalR2.setEnabled(false);
									if(modoSumaR2 == 1|| modoRestaR2 == 1 || modoProdEscalarR2 == 1|| modoEscalarR2 == 1)
									{
										desactivarBotonesOperaciones();
										btnResultadoFinalR2.setEnabled(true);
										btnDel.setEnabled(true);
										btnClear.setEnabled(true);
									}
								}
								btnNegativePositive.setEnabled(true);
								btnDivideComponentes.setEnabled(true);
								String ingresenumero1 = txtNumero2R2.getText() + btnComa.getText();
								txtNumero2R2.setText(ingresenumero1);
								ingresenumero1 = null;
								btnComa.setEnabled(false);
							}

							if(modoEscalarR2 == 1)
							{
								btnNegativePositive.setEnabled(true);
								btnDivideComponentes.setEnabled(false);
								String ingresenumero2 = txtEscalarR2.getText() + btnComa.getText();
								txtEscalarR2.setText(ingresenumero2);
								ingresenumero2 = null;
								btnComa.setEnabled(false);
							}	
						}
						if(modoR3 == 1)
						{
							if(txtNumero1R3.getText().length() +1 > 0 || txtNumero2R3.getText().length() +1 > 0 || txtNumero3R3.getText().length() +1 > 0 || txtEscalarR3.getText().length() +1 > 0)
							{
								btnDel.setEnabled(true);
								btnClear.setEnabled(true);
							}
							if(txtNumero2R3.getText().length() == 0)//arreglar :)
							{
								btnDivideComponentes.setEnabled(false);
							}
							if(txtNumero1R3.getText() == null || txtNumero2R3.getText() == null || txtNumero3R3.getText() == null || txtEscalarR2.getText() == null)
							{
								btnNegativePositive.setEnabled(false);
								btnComa.setEnabled(false);
							}
							if(segundoterminoR3 == 0)
							{
								btnNegativePositive.setEnabled(true);
								btnDivideComponentes.setEnabled(true);
								String ingresenumero = txtNumero1R3.getText() + btnComa.getText();
								txtNumero1R3.setText(ingresenumero);
								ingresenumero = null;
								btnComa.setEnabled(false);
							}
							
							if(segundoterminoR3 == 1)
							{
								btnNegativePositive.setEnabled(true);
								btnDivideComponentes.setEnabled(true);
								String ingresenumero1 = txtNumero2R3.getText() + btnComa.getText();
								txtNumero2R3.setText(ingresenumero1);
								ingresenumero1 = null;
								btnComa.setEnabled(false);
							}
							
							if(segundoterminoR3 == 2)
							{
								if(txtNumero1R2.getText().length() +1 > 0 && txtNumero2R2.getText().length() +1 > 0)
								{
									activarBotonesOperaciones();
									btnResultadoFinalR2.setEnabled(false);
									if(modoSumaR3 == 1|| modoRestaR3 == 1 || modoProdEscalarR3 == 1|| modoEscalarR3 == 1)
									{
										desactivarBotonesOperaciones();
										btnResultadoFinalR2.setEnabled(true);
										btnDel.setEnabled(true);
										btnClear.setEnabled(true);
									}
								}
								btnNegativePositive.setEnabled(true);
								btnDivideComponentes.setEnabled(true);
								String ingresenumero3 = txtNumero3R3.getText() + btnComa.getText();
								txtNumero3R3.setText(ingresenumero3);
								ingresenumero3 = null;
								btnComa.setEnabled(false);
							}
							
							if(modoEscalarR3 == 1)
							{
								btnNegativePositive.setEnabled(true);
								btnDivideComponentes.setEnabled(false);
								String ingresenumero2 = txtEscalarR3.getText() + btnComa.getText();
								txtEscalarR3.setText(ingresenumero2);
								ingresenumero2 = null;
								btnComa.setEnabled(false);
							}
						}
					}
				});
		hover(btnComa);

		btnDivideComponentes.setForeground(new Color(255, 255, 255));
		btnDivideComponentes.setIcon(new ImageIcon(VectoresMain.class.getResource("/img/divideR2.png")));
		btnDivideComponentes.setDisabledIcon(new ImageIcon(VectoresMain.class.getResource("/img/divideR2Disabled.png")));
		btnDivideComponentes.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnDivideComponentes.setBackground(new Color(0, 220, 235));
		btnDivideComponentes.setToolTipText("Elegir componente del vector");
		panelBotones.add(btnDivideComponentes);
        hover(btnDivideComponentes);
		btnDivideComponentes.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(modoR3 == 0)
				{
					modoNormalR2 = 1;
					if(modoSumaR2 == 1 || modoRestaR2 == 1 || modoProdEscalarR2 == 1)
					{
						txtNumero1R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero2R2.setBorder(border);
						if(txtNumero2R2.getText().length() > 0)
						{
							btnResultadoFinalR2.setEnabled(true);
						}
						modoNormalR2 = 0;
						btnNegativePositive.setEnabled(false);
						btnComa.setEnabled(false);
						btnDel.setEnabled(false);
						btnClear.setEnabled(false);
						String numeroingresado = txtNumero1R2.getText();
						double temp = Double.parseDouble(numeroingresado);
						c = temp;
						temp = 0;
						cMostrar = mostrarSinDecimal(numeroingresado, c, cMostrar);						
					}
					
					if(modoNormalR2 == 1)
					{
						txtNumero1R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero2R2.setBorder(border);
						btnDel.setEnabled(false);
						btnClear.setEnabled(false);
						btnNegativePositive.setEnabled(false);
						btnComa.setEnabled(false);
						String numeroingresado = txtNumero1R2.getText();
						double temp = Double.parseDouble(numeroingresado);
						a = temp;
						temp = 0;
						aMostrar = mostrarSinDecimal(numeroingresado, a, aMostrar);
					}

					if(segundoterminoR2 == 0)
					{
						segundoterminoR2 = 1;
					}
					
					else if(segundoterminoR2 == 1)
			        {
			        	segundoterminoR2 = 0;
			        	txtNumero2R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero1R2.setBorder(border);
			        }	
				}
				
				if(modoR3 == 1)
				{
					boolean capturandoPrimerVector = true;
					cont++;

			        // Si estamos en modo de alguna operación, cambiamos al segundo vector
			        if(modoSumaR3 == 1 || modoRestaR3 == 1 || modoProdEscalarR3 == 1 || modoProdVectorial == 1)
			        {
			            modoNormalR3 = 0;
			            if (capturandoPrimerVector)
			            {
			            	txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
			            	txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
							txtNumero1R3.setBorder(border);
			            	btnDel.setEnabled(false);
							btnClear.setEnabled(false);
			            	btnNegativePositive.setEnabled(false);
							btnComa.setEnabled(false);
			                String numeroingresado = txtNumero1R3.getText();
			                double temp = Double.parseDouble(numeroingresado);
			                d = temp;
			                temp = 0;
			                dMostrar = mostrarSinDecimal(numeroingresado, d, dMostrar);
			                capturandoSegundoVector = true;
			                capturandoPrimerVector = false; // Terminamos de capturar el primer vector
			            }
			        }
			        else
			        {
			            modoNormalR3 = 1; // Modo normal cuando no se está haciendo ninguna cuenta
			        }

			        // Capturamos el segundo componente del segundo vector
			        if(capturandoSegundoVector && !capturandoPrimerVector && cont == 2)
			        {
			        	txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
		            	txtNumero1R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero2R3.setBorder(border);
			        	btnNegativePositive.setEnabled(false);
						btnComa.setEnabled(false);
			            String numeroingresado = txtNumero2R3.getText();
			            double temp = Double.parseDouble(numeroingresado);
			            E = temp;
			            temp = 0;
			            eMostrar = mostrarSinDecimal(numeroingresado, E, eMostrar);
			            capturandoSegundoVector = false;
			            cont = 0; // Reiniciamos el contador después de capturar el segundo componente
		                btnDivideComponentes.setEnabled(false);
			        }

			        // Capturamos el primer vector
			        if(modoNormalR3 == 1 && capturandoPrimerVector)
			        {
			            if (cont == 1)
			            { // Primer componente del primer vector
			            	btnDel.setEnabled(false);
							btnClear.setEnabled(false);
			            	btnNegativePositive.setEnabled(false);
							btnComa.setEnabled(false);
			                String numeroingresado = txtNumero1R3.getText();
			                double temp = Double.parseDouble(numeroingresado);
			                a = temp;
			                temp = 0;
			                aMostrar = mostrarSinDecimal(numeroingresado, a, aMostrar);
			            }
			            else if (cont == 2)
			            { // Segundo componente del primer vector
			            	btnDivideComponentes.setEnabled(false);
			            	btnDel.setEnabled(false);
							btnClear.setEnabled(false);
			            	btnNegativePositive.setEnabled(false);
							btnComa.setEnabled(false);
			                String numeroingresado = txtNumero2R3.getText();
			                double temp = Double.parseDouble(numeroingresado);
			                b = temp;
			                temp = 0;
			                bMostrar = mostrarSinDecimal(numeroingresado, b, bMostrar);
			                capturandoPrimerVector = false; // Terminamos de capturar el primer vector
			                cont = 0; // Reiniciamos el contador después de capturar ambos componentes del primer vector
			            }
			        }
					//A partir de acá la lógica de esto no interviene en lo de arriba
					if(segundoterminoR3 == 0)
					{
						segundoterminoR3 = 1;
						txtNumero1R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
		            	txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero2R3.setBorder(border);
						if(modoNormalR3 == 1)
						{
							btnDivideComponentes.setEnabled(false);	
						}
						else
						{
							btnDivideComponentes.setEnabled(true);
						}
					}
					
					else if(segundoterminoR3 == 1)
			        {
			        	segundoterminoR3 = 2;
			        	txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
		            	txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero3R3.setBorder(border);
			        }
					
					else if(segundoterminoR3 == 2)
					{
						segundoterminoR3 = 0;
						txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
		            	txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
						txtNumero1R3.setBorder(border);
					}
				}
			}
		});
	}
	private void panelBotonesOperaciones()
	{
		contentPane.add(panelOperaciones);
		panelOperaciones.setLayout(new GridLayout(1, 1, 1, 1));
		btnSumaR2.setForeground(Color.WHITE);
		btnSumaR2.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnSumaR2.setEnabled(false);
		btnSumaR2.setBackground(new Color(0, 220, 235));
		hover(btnSumaR2);
		btnSumaR2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(modoR3 == 0)
				{
					txtNumero2R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					txtNumero1R2.setBorder(border);
					desactivarBotonesOperaciones();
					btnComa.setEnabled(false);
					btnNegativePositive.setEnabled(false);
				    btnDivideComponentes.setEnabled(false);
					String numeroingresado = txtNumero2R2.getText();
					double temp = Double.parseDouble(numeroingresado);
					b = temp;
					temp = 0;
					bMostrar = mostrarSinDecimal(numeroingresado, b, bMostrar);
					modoSumaR2 = 1;
					segundoterminoR2 = 0;
					txtNumero1R2.setText(null);
					txtNumero2R2.setText(null);
					lblCC.setText("("+aMostrar+", "+bMostrar+") + ");
					lblCC.setVisible(true);
				}
				if(modoR3 == 1)
				{
					txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
	            	txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					txtNumero1R3.setBorder(border);
					desactivarBotonesOperaciones();
					btnComa.setEnabled(false);
					btnNegativePositive.setEnabled(false);
					btnDivideComponentes.setEnabled(false);
					String numeroingresado = txtNumero3R3.getText();
					double temp = Double.parseDouble(numeroingresado);
					c = temp;
					temp = 0;
					cMostrar = mostrarSinDecimal(numeroingresado, c, cMostrar);
					modoSumaR3 = 1;
					segundoterminoR3 = 0;
					txtNumero1R3.setText(null);
					txtNumero2R3.setText(null);
					txtNumero3R3.setText(null);
					lblCCR3.setText("("+aMostrar+", "+bMostrar+", "+cMostrar+") + ");
					lblCCR3.setVisible(true);
				}
			}
		});
		
		panelOperaciones.add(btnSumaR2);
		btnRestaR2.setForeground(Color.WHITE);
		btnRestaR2.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnRestaR2.setEnabled(false);
		btnRestaR2.setBackground(new Color(0, 220, 235));
		hover(btnRestaR2);
		btnRestaR2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(modoR3 == 0)
				{
					txtNumero2R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					txtNumero1R2.setBorder(border);
					desactivarBotonesOperaciones();
					btnComa.setEnabled(false);
					btnNegativePositive.setEnabled(false);
					btnDivideComponentes.setEnabled(false);
					String numeroingresado = txtNumero2R2.getText();
					double temp = Double.parseDouble(numeroingresado);
					b = temp;
					temp = 0;
					bMostrar = mostrarSinDecimal(numeroingresado, b, bMostrar);
					modoRestaR2 = 1;
					segundoterminoR2 = 0;
					txtNumero1R2.setText(null);
					txtNumero2R2.setText(null);
					lblCC.setText("("+aMostrar+", "+bMostrar+") - ");
					lblCC.setVisible(true);
				}
				
				if(modoR3 == 1)
				{
					txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
	            	txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					txtNumero1R3.setBorder(border);
					desactivarBotonesOperaciones();
					btnComa.setEnabled(false);
					btnNegativePositive.setEnabled(false);
					btnDivideComponentes.setEnabled(false);
					String numeroingresado = txtNumero3R3.getText();
					double temp = Double.parseDouble(numeroingresado);
					c = temp;
					temp = 0;
					cMostrar = mostrarSinDecimal(numeroingresado, c, cMostrar);
					modoRestaR3 = 1;
					segundoterminoR3 = 0;
					txtNumero1R3.setText(null);
					txtNumero2R3.setText(null);
					txtNumero3R3.setText(null);
					lblCCR3.setText("("+aMostrar+", "+bMostrar+", "+cMostrar+") - ");
					lblCCR3.setVisible(true);
				}
			}
		});
		
		panelOperaciones.add(btnRestaR2);
		btnMultiplicarR2.setForeground(Color.WHITE);
		btnMultiplicarR2.setIcon(new ImageIcon(VectoresMain.class.getResource("/img/prodEscalar.png")));
		btnMultiplicarR2.setDisabledIcon(new ImageIcon(VectoresMain.class.getResource("/img/prodEscalarDisabled.png")));
		btnMultiplicarR2.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnMultiplicarR2.setEnabled(false);
		btnMultiplicarR2.setBackground(new Color(0, 220, 235));
		btnMultiplicarR2.setToolTipText("Producto Escalar");
		hover(btnMultiplicarR2);
		btnMultiplicarR2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(modoR3 == 0)
				{
					txtNumero2R2.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					txtNumero1R2.setBorder(border);
					desactivarBotonesOperaciones();
					btnComa.setEnabled(false);
					btnNegativePositive.setEnabled(false);
					btnDivideComponentes.setEnabled(false);
					String numeroingresado = txtNumero2R2.getText();
					double temp = Double.parseDouble(numeroingresado);
					b = temp;
					temp = 0;
					bMostrar = mostrarSinDecimal(numeroingresado, b, bMostrar);
					modoProdEscalarR2 = 1;
					segundoterminoR2 = 0;
					txtNumero1R2.setText(null);
					txtNumero2R2.setText(null);
					lblCC.setText("("+aMostrar+", "+bMostrar+") * ");
					lblCC.setVisible(true);
				}
				
				if(modoR3 == 1)
				{
					txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
	            	txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					txtNumero1R3.setBorder(border);
					desactivarBotonesOperaciones();
					btnComa.setEnabled(false);
					btnNegativePositive.setEnabled(false);
					btnDivideComponentes.setEnabled(false);
					String numeroingresado = txtNumero3R3.getText();
					double temp = Double.parseDouble(numeroingresado);
					c = temp;
					temp = 0;
					cMostrar = mostrarSinDecimal(numeroingresado, c, cMostrar);
					modoProdEscalarR3 = 1;
					segundoterminoR3 = 0;
					txtNumero1R3.setText(null);
					txtNumero2R3.setText(null);
					txtNumero3R3.setText(null);
					lblCCR3.setText("("+aMostrar+", "+bMostrar+", "+cMostrar+") * ");
					lblCCR3.setVisible(true);
				}
			}
		});
		
		panelOperaciones.add(btnMultiplicarR2);
		btnMultiplicarEscalarR2.setForeground(Color.WHITE);
		btnMultiplicarEscalarR2.setIcon(new ImageIcon(VectoresMain.class.getResource("/img/multPorEscalar.png")));
		btnMultiplicarEscalarR2.setDisabledIcon(new ImageIcon(VectoresMain.class.getResource("/img/escalarDisabled.png")));
		btnMultiplicarEscalarR2.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnMultiplicarEscalarR2.setEnabled(false);
		btnMultiplicarEscalarR2.setBackground(new Color(0, 220, 235));
		btnMultiplicarEscalarR2.setToolTipText("Multiplicar por un escalar");
		panelOperaciones.add(btnMultiplicarEscalarR2);
		hover(btnMultiplicarEscalarR2);
		btnMultiplicarEscalarR2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(modoR3 == 0)
				{
					txtEscalarR2.setBorder(border);
					desactivarBotonesOperaciones();
					btnComa.setEnabled(false);
					btnNegativePositive.setEnabled(false);
					btnDivideComponentes.setEnabled(false);
					String numeroingresado = txtNumero2R2.getText();
					double temp = Double.parseDouble(numeroingresado);
					b = temp;
					temp = 0;
					bMostrar = mostrarSinDecimal(numeroingresado, b, bMostrar);
					panelResultadosR2.setVisible(false);
					panelEscalarR2.setVisible(true);
					modoEscalarR2 = 1;
					btnDivideComponentes.setEnabled(false);
					txtEscalarR2.setText(null);
					lblCCE.setText("("+aMostrar+", "+bMostrar+") * ");
					lblCCE.setVisible(true);
				}
				if(modoR3 == 1)
				{
					txtEscalarR3.setBorder(border);
					desactivarBotonesOperaciones();
					btnComa.setEnabled(false);
					btnNegativePositive.setEnabled(false);
					btnDivideComponentes.setEnabled(false);
					String numeroingresado = txtNumero3R3.getText();
					double temp = Double.parseDouble(numeroingresado);
					c = temp;
					temp = 0;
					cMostrar = mostrarSinDecimal(numeroingresado, c, cMostrar);
					panelResultadosR3.setVisible(false);
					panelEscalarR3.setVisible(true);
					modoEscalarR3 = 1;
					btnDivideComponentes.setEnabled(false);
					txtEscalarR3.setText(null);
					lblCCER3.setText("("+aMostrar+", "+bMostrar+", "+cMostrar+") * ");
					lblCCER3.setVisible(true);
				}
			}
		});
		
		btnProdVectorial.setForeground(new Color(255, 255, 255));
		btnProdVectorial.setIcon(new ImageIcon(VectoresMain.class.getResource("/img/vectores.png")));
		btnProdVectorial.setDisabledIcon(new ImageIcon(VectoresMain.class.getResource("/img/vectorialDisabled.png")));
		btnProdVectorial.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		btnProdVectorial.setBackground(new Color(0, 220, 235));
		btnProdVectorial.setToolTipText("Producto Vectorial");
		hover(btnProdVectorial);
		btnProdVectorial.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(modoR3 == 1)
				{
					txtNumero1R3.setBorder(border);
					txtNumero2R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					txtNumero3R3.setBorder(new LineBorder(new Color(77, 77, 77), 2, true));
					desactivarBotonesOperaciones();
					btnComa.setEnabled(false);
					btnNegativePositive.setEnabled(false);
					btnDivideComponentes.setEnabled(false);
					String numeroingresado = txtNumero3R3.getText();
					double temp = Double.parseDouble(numeroingresado);
					c = temp;
					temp = 0;
					cMostrar = mostrarSinDecimal(numeroingresado, c, cMostrar);
					modoProdVectorial = 1;
					btnDivideComponentes.setEnabled(false);
					segundoterminoR3 = 0;
					txtNumero1R3.setText(null);
					txtNumero2R3.setText(null);
					txtNumero3R3.setText(null);
					lblCCR3.setText("("+aMostrar+", "+bMostrar+", "+cMostrar+") ^ ");
					lblCCR3.setVisible(true);
				}
			}
		});
		
	}
	private void insertarnum(JButton boton)
	{
		boton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(modoR3 == 0)
				{
					if(txtNumero1R2.getText().length() +1 > 0 || txtNumero2R2.getText().length() +1 > 0 || txtEscalarR2.getText().length() +1 > 0)
					{
						btnDel.setEnabled(true);
						btnClear.setEnabled(true);
					}
					if(txtNumero1R2.getText().contains("."))
					{
						btnComa.setEnabled(false);
					}
					else if(txtNumero2R2.getText().contains("."))
					{
						btnComa.setEnabled(false);
					}
					else if(txtEscalarR2.getText().contains("."))
					{
						btnComa.setEnabled(false);
					}
					else
					{
						btnComa.setEnabled(true);
					}
					if(txtNumero1R2.getText() == null || txtNumero2R2.getText() == null || txtEscalarR2.getText() == null)
					{
						btnNegativePositive.setEnabled(false);
						btnComa.setEnabled(false);
					}
					if(segundoterminoR2 == 0)
					{
						btnComa.setEnabled(true);
						if(txtNumero1R2.getText().contains("."))
						{
							btnComa.setEnabled(false);
						}
						btnNegativePositive.setEnabled(true);
						btnDivideComponentes.setEnabled(true);
						String ingresenumero = txtNumero1R2.getText() + boton.getText();
						txtNumero1R2.setText(ingresenumero);
						ingresenumero = null;
					}
					
					if(segundoterminoR2 == 1)
					{
						btnComa.setEnabled(true);
						if(txtNumero2R2.getText().contains("."))
						{
							btnComa.setEnabled(false);
						}
						if(txtNumero1R2.getText().length() +1 > 0 && txtNumero2R2.getText().length() +1 > 0)
						{
							activarBotonesOperaciones();
							btnResultadoFinalR2.setEnabled(false);
							if(modoSumaR2 == 1|| modoRestaR2 == 1 || modoProdEscalarR2 == 1|| modoEscalarR2 == 1)
							{
								desactivarBotonesOperaciones();
								btnResultadoFinalR2.setEnabled(true);
								btnDel.setEnabled(true);
								btnClear.setEnabled(true);
							}
						}
						btnNegativePositive.setEnabled(true);
						btnDivideComponentes.setEnabled(true);
						String ingresenumero1 = txtNumero2R2.getText() + boton.getText();
						txtNumero2R2.setText(ingresenumero1);
						ingresenumero1 = null;
					}

					if(modoEscalarR2 == 1)
					{
						btnComa.setEnabled(true);
						if(txtEscalarR2.getText().contains("."))
						{
							btnComa.setEnabled(false);
						}
						btnNegativePositive.setEnabled(true);
						btnDivideComponentes.setEnabled(false);
						String ingresenumero2 = txtEscalarR2.getText() + boton.getText();
						txtEscalarR2.setText(ingresenumero2);
						ingresenumero2 = null;
					}	
				}
				if(modoR3 == 1)
				{
					if(txtNumero1R3.getText().length() +1 > 0 || txtNumero2R3.getText().length() +1 > 0 || txtNumero3R3.getText().length() +1 > 0 || txtEscalarR3.getText().length() +1 > 0)
					{
						btnDel.setEnabled(true);
						btnClear.setEnabled(true);
					}
					if(txtNumero2R3.getText().length() == 0)//arreglar :)
					{
						btnDivideComponentes.setEnabled(false);
					}
					if(txtNumero1R3.getText().contains("."))
					{
						btnComa.setEnabled(false);
					}
					else if(txtNumero2R3.getText().contains("."))
					{
						btnComa.setEnabled(false);
					}
					else if(txtNumero3R3.getText().contains("."))
					{
						btnComa.setEnabled(false);
					}
					else if(txtEscalarR3.getText().contains("."))
					{
						btnComa.setEnabled(false);
					}
					else
					{
						btnComa.setEnabled(true);
					}
					if(txtNumero1R3.getText() == null || txtNumero2R3.getText() == null || txtNumero3R3.getText() == null || txtEscalarR2.getText() == null)
					{
						btnNegativePositive.setEnabled(false);
						btnComa.setEnabled(false);
					}
					if(segundoterminoR3 == 0)
					{
						btnComa.setEnabled(true);
						if(txtNumero1R3.getText().contains("."))
						{
							btnComa.setEnabled(false);
						}
						btnNegativePositive.setEnabled(true);
						btnDivideComponentes.setEnabled(true);
						String ingresenumero = txtNumero1R3.getText() + boton.getText();
						txtNumero1R3.setText(ingresenumero);
						ingresenumero = null;
					}
					
					if(segundoterminoR3 == 1)
					{
						btnComa.setEnabled(true);
						if(txtNumero2R3.getText().contains("."))
						{
							btnComa.setEnabled(false);
						}
						btnNegativePositive.setEnabled(true);
						btnDivideComponentes.setEnabled(true);
						String ingresenumero1 = txtNumero2R3.getText() + boton.getText();
						txtNumero2R3.setText(ingresenumero1);
						ingresenumero1 = null;
					}
					
					if(segundoterminoR3 == 2)
					{
						btnComa.setEnabled(true);
						if(txtNumero3R3.getText().contains("."))
						{
							btnComa.setEnabled(false);
						}
						if(txtNumero1R2.getText().length() +1 > 0 && txtNumero2R2.getText().length() +1 > 0)
						{
							activarBotonesOperaciones();
							btnResultadoFinalR2.setEnabled(false);
							if(modoSumaR3 == 1|| modoRestaR3 == 1 || modoProdEscalarR3 == 1|| modoEscalarR3 == 1 || modoProdVectorial == 1)
							{
								desactivarBotonesOperaciones();
								btnResultadoFinalR2.setEnabled(true);
								btnDel.setEnabled(true);
								btnClear.setEnabled(true);
							}
						}
						btnNegativePositive.setEnabled(true);
						btnDivideComponentes.setEnabled(true);
						String ingresenumero3 = txtNumero3R3.getText() + boton.getText();
						txtNumero3R3.setText(ingresenumero3);
						ingresenumero3 = null;
					}
					
					if(modoEscalarR3 == 1)
					{
						btnComa.setEnabled(true);
						if(txtEscalarR3.getText().contains("."))
						{
							btnComa.setEnabled(false);
						}
						btnNegativePositive.setEnabled(true);
						btnDivideComponentes.setEnabled(false);
						String ingresenumero2 = txtEscalarR3.getText() + boton.getText();
						txtEscalarR3.setText(ingresenumero2);
						ingresenumero2 = null;
					}
				}
			}
		});
	}
	private void desactivarBotonesOperaciones() {
		btnMultiplicarR2.setEnabled(false);
	    btnSumaR2.setEnabled(false);
	    btnRestaR2.setEnabled(false);
	    btnMultiplicarEscalarR2.setEnabled(false);
	    btnResultadoFinalR2.setEnabled(false);
	    btnDel.setEnabled(false);
	    btnClear.setEnabled(false);
	    btnProdVectorial.setEnabled(false);
	}

	private void activarBotonesOperaciones() {
		btnMultiplicarR2.setEnabled(true);
	    btnSumaR2.setEnabled(true);
	    btnRestaR2.setEnabled(true);
	    btnMultiplicarEscalarR2.setEnabled(true);
	    btnResultadoFinalR2.setEnabled(true);
	    btnDel.setEnabled(true);
	    btnClear.setEnabled(true);
	    btnProdVectorial.setEnabled(true);
	}
	private void hover(JButton boton)
	{
		boton.setBorder(null);
		boton.setFocusPainted(false);
		Color normalColor = boton.getBackground();
		int rojo = normalColor.getRed();
		int verde = normalColor.getGreen();
		int azul = normalColor.getBlue();
		int rojoN = rojo + 30;
		int verdeN = verde + 30;
		int azulN = azul + 30;
		if(rojoN > 255)
		{
			rojoN = 255;
		}
		if(verdeN > 255)
		{
			verdeN = 255;
		}
		if(azulN > 255)
		{
			azulN = 255;
		}
		
        Color hoverColor = new Color(rojoN, verdeN, azulN);
        
    	boton.addMouseListener(new MouseAdapter() {
            Timer enterTimer;
            Timer exitTimer;

            public void mouseEntered(MouseEvent e) {
                if (exitTimer != null && exitTimer.isRunning()) {
                    exitTimer.stop();
                }
                enterTimer = createColorTransitionTimer(boton, normalColor, hoverColor);
                enterTimer.start();
            }

            public void mouseExited(MouseEvent e) {
                if (enterTimer != null && enterTimer.isRunning()) {
                    enterTimer.stop();
                }
                exitTimer = createColorTransitionTimer(boton, hoverColor, normalColor);
                exitTimer.start();
            }
    	});
	}
	private static Timer createColorTransitionTimer(JButton button, Color startColor, Color endColor) {
        return new Timer(ANIMATION_DELAY, null) {
			private static final long serialVersionUID = -4701965186790357155L;
			long startTime = System.currentTimeMillis();

            {
                addActionListener(e -> {
                    long elapsed = System.currentTimeMillis() - startTime;
                    float progress = Math.min(1.0f, (float) elapsed / ANIMATION_DURATION);
                    button.setBackground(interpolateColor(startColor, endColor, progress));
                    if (progress >= 1.0f) {
                        ((Timer) e.getSource()).stop();
                    }
                });
            }
        };
    }

    private static Color interpolateColor(Color startColor, Color endColor, float fraction) {
        int red = (int) (startColor.getRed() + (endColor.getRed() - startColor.getRed()) * fraction);
        int green = (int) (startColor.getGreen() + (endColor.getGreen() - startColor.getGreen()) * fraction);
        int blue = (int) (startColor.getBlue() + (endColor.getBlue() - startColor.getBlue()) * fraction);
        return new Color(red, green, blue);
    }
    
    private void desactivarBotonesFunciones()
    {
    	btnNum1.setEnabled(false);
    	btnNum2.setEnabled(false);
    	btnNum3.setEnabled(false);
    	btnNum4.setEnabled(false);
    	btnNum5.setEnabled(false);
    	btnNum6.setEnabled(false);
    	btnNum7.setEnabled(false);
    	btnNum8.setEnabled(false);
    	btnNum9.setEnabled(false);
    	btnNum0.setEnabled(false);
    	btnNegativePositive.setEnabled(false);
    	btnComa.setEnabled(false);
    }
    private void activarBotonesFunciones()
    {
    	btnNum1.setEnabled(true);
    	btnNum2.setEnabled(true);
    	btnNum3.setEnabled(true);
    	btnNum4.setEnabled(true);
    	btnNum5.setEnabled(true);
    	btnNum6.setEnabled(true);
    	btnNum7.setEnabled(true);
    	btnNum8.setEnabled(true);
    	btnNum9.setEnabled(true);
    	btnNum0.setEnabled(true);
    }
    private String mostrarSinDecimal(String numing, double valor, String mostrar)
    {
        if (valor % 1 == 0)
        {
            mostrar = String.valueOf((int) valor);
        }
        else
        {
        	DecimalFormatSymbols symbols = new DecimalFormatSymbols();
            symbols.setDecimalSeparator('.');
            DecimalFormat formato = new DecimalFormat("#.####", symbols);
            mostrar = formato.format(valor);
            
            if (mostrar.endsWith("."))
            {
                mostrar = mostrar.substring(0, mostrar.length() - 1);
            }
        }

        return mostrar;
    }
    private String mostrarSinDecimal2(double valor, int decimales)
    {
        if (valor % 1 == 0)
        {
        	if(valor == -0)
            {
            	valor = 0;
            }
            return String.valueOf((int) valor);
        }
        else
        {
        	DecimalFormatSymbols symbols = new DecimalFormatSymbols();
            symbols.setDecimalSeparator('.');
        	StringBuilder pattern = new StringBuilder("#.");
            for (int i = 0; i < decimales; i++) {
                pattern.append("#");
            }
            DecimalFormat formato = new DecimalFormat(pattern.toString(), symbols);
            return formato.format(valor);
        }
    }
}