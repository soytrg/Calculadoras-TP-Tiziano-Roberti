package gui;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.BoxLayout;

public class Calculador_a extends JFrame {
    private static final long serialVersionUID = 1L;
    private JTextField pantalla;
    private JLabel caretLabel;
    private JPanel panelNumerico;
    private JPanel panelHistorial;
    private JPanel panelBotonVolver;
    private List<String> historial;
    private int indiceHistorial;
    private double respuestaAnterior;
    private static final double PI = Math.PI;
    private boolean resultadoMostrado;
    private JPanel panelBotonesFlecha;
    private static final int ANIMATION_DURATION = 250; // Duración de la animación en milisegundos
    private static final int ANIMATION_DELAY = 20; // Retraso entre cada paso de la animación en milisegundos

    public Calculador_a() {
        setTitle("Calculadora Estandar");
        setSize(600, 700);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);

        historial = new ArrayList<>();
        indiceHistorial = -1;
        respuestaAnterior = 0;
        resultadoMostrado = false;

        pantalla = new JTextField("0");
        pantalla.setEditable(false);
        pantalla.setFont(new Font("Segoe UI", Font.PLAIN, 38));
        pantalla.setBackground(new Color(51, 51, 51));
        pantalla.setForeground(new Color(255, 255, 255));
        pantalla.setHorizontalAlignment(SwingConstants.RIGHT);
        pantalla.setCaretColor(Color.WHITE);
        pantalla.setMargin(new Insets(10, 20, 10, 20));

        caretLabel = new JLabel();
        caretLabel.setFont(new Font("Segoe UI", Font.PLAIN, 38));
        caretLabel.setForeground(Color.WHITE);

        JPanel panelPantalla = new JPanel(new BorderLayout());
        panelPantalla.setBackground(new Color(51, 51, 51));
        panelPantalla.setBorder(new EmptyBorder(10, 20, 10, 20));
        panelPantalla.add(pantalla, BorderLayout.CENTER);
        panelPantalla.add(caretLabel, BorderLayout.SOUTH);

        JPanel panelSuperior = new JPanel(new BorderLayout());
        getContentPane().add(panelSuperior, BorderLayout.CENTER);

        panelNumerico = new JPanel();
        panelNumerico.setLayout(new GridLayout(6, 4, 1, 1));
        panelNumerico.setBackground(new Color(51, 51, 51));
        panelNumerico.setBorder(new EmptyBorder(0, 20, 40, 68));
        panelSuperior.add(panelNumerico, BorderLayout.CENTER);

        agregarBotonesCalculadora();

        panelBotonesFlecha = new JPanel();
        panelBotonesFlecha.setLayout(new BoxLayout(panelBotonesFlecha, BoxLayout.LINE_AXIS));
        panelBotonesFlecha.setBackground(new Color(51, 51, 51));
        panelBotonesFlecha.setBorder(new EmptyBorder(10, 10, 10, 10));
        panelPantalla.add(panelBotonesFlecha, BorderLayout.SOUTH);

        JButton botonIzquierda = new JButton("←");
        botonIzquierda.setFont(new Font("Segoe UI", Font.PLAIN, 38));
        botonIzquierda.setBackground(new Color(0, 150, 255));
        botonIzquierda.setForeground(Color.WHITE);
        botonIzquierda.setBorderPainted(false);
        botonIzquierda.setFocusPainted(false);
        botonIzquierda.setMargin(new Insets(15, 160, 15, 40));
        botonIzquierda.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int posicionActual = pantalla.getCaretPosition();
                if (posicionActual > 0) {
                    pantalla.setCaretPosition(posicionActual - 1);
                }
            }
        });
        panelBotonesFlecha.add(botonIzquierda);

        JButton botonDerecha = new JButton("→");
        botonDerecha.setFont(new Font("Segoe UI", Font.PLAIN, 38));
        botonDerecha.setBackground(new Color(0, 150, 255));
        botonDerecha.setForeground(Color.WHITE);
        botonDerecha.setBorderPainted(false);
        botonDerecha.setFocusPainted(false);
        botonDerecha.setMargin(new Insets(15, 40, 15, 160));
        botonDerecha.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int posicionActual = pantalla.getCaretPosition();
                if (posicionActual < pantalla.getText().length()) {
                    pantalla.setCaretPosition(posicionActual + 1);
                }
            }
        });
        panelBotonesFlecha.add(botonDerecha);

        panelHistorial = new JPanel();
        panelHistorial.setLayout(new BoxLayout(panelHistorial, BoxLayout.Y_AXIS));
        panelHistorial.setBackground(new Color(51, 51, 51));
        panelHistorial.setBorder(new EmptyBorder(10, 10, 10, 10));
        panelPantalla.add(panelHistorial, BorderLayout.EAST);

        JButton botonUp = new JButton("↑");
        panelHistorial.add(botonUp);
        botonUp.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        botonUp.setBackground(new Color(0, 150, 255));
        botonUp.setForeground(Color.WHITE);
        botonUp.setBorderPainted(false);
        botonUp.setFocusPainted(false);
        botonUp.setMargin(new Insets(5, 5, 5, 5));

        JButton botonDown = new JButton("↓");
        panelHistorial.add(botonDown);
        botonDown.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        botonDown.setBackground(new Color(0, 150, 255));
        botonDown.setForeground(Color.WHITE);
        botonDown.setBorderPainted(false);
        botonDown.setFocusPainted(false);
        botonDown.setMargin(new Insets(5, 5, 5, 5));

        botonDown.addActionListener(new ManejarBotonHistorial());
        botonUp.addActionListener(new ManejarBotonHistorial());

        panelSuperior.add(panelPantalla, BorderLayout.NORTH);

        getContentPane().setBackground(new Color(51, 51, 51));

        panelBotonVolver = new JPanel();
        panelBotonVolver.setBackground(new Color(51, 51, 51));
        panelBotonVolver.setBorder(new EmptyBorder(0, 0, 0, 510));
        panelBotonVolver.setLayout(new BorderLayout());

        JButton botonVolver = new JButton("Volver");
        botonVolver.addActionListener(e -> {
        	dispose();
        });
        botonVolver.setVerticalAlignment(SwingConstants.BOTTOM);
        botonVolver.setBackground(new Color(77, 77, 77));
        botonVolver.setForeground(Color.WHITE);
        botonVolver.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        botonVolver.setBorderPainted(false);
        botonVolver.setFocusPainted(false);
        botonVolver.setPreferredSize(new Dimension(30, 30));

        panelBotonVolver.add(botonVolver, BorderLayout.CENTER);
        getContentPane().add(panelBotonVolver, BorderLayout.NORTH);

        setVisible(true);

        pantalla.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                caretLabel.setText("");
            }

            @Override
            public void focusGained(FocusEvent e) {
                actualizarCaretLabel();
            }
        });
    }

    private void actualizarCaretLabel() {
        int posicionActual = pantalla.getCaretPosition();
        String texto = pantalla.getText();
        caretLabel.setText(texto.substring(0, posicionActual) + "|" + texto.substring(posicionActual));
    }

    private void agregarBotonesCalculadora() {
        agregarBoton("7", 18, new Color(77, 77, 77), Color.WHITE);
        agregarBoton("8", 18, new Color(77, 77, 77), Color.WHITE);
        agregarBoton("9", 18, new Color(77, 77, 77), Color.WHITE);
        agregarBoton("C", 18, new Color(0, 150, 255), Color.WHITE);

        agregarBoton("4", 18, new Color(77, 77, 77), Color.WHITE);
        agregarBoton("5", 18, new Color(77, 77, 77), Color.WHITE);
        agregarBoton("6", 18, new Color(77, 77, 77), Color.WHITE);
        agregarBoton("DEL", 18, new Color(0, 150, 255), Color.WHITE);

        agregarBoton("1", 18, new Color(77, 77, 77), Color.WHITE);
        agregarBoton("2", 18, new Color(77, 77, 77), Color.WHITE);
        agregarBoton("3", 18, new Color(77, 77, 77), Color.WHITE);
        agregarBoton("=", 18, new Color(0, 175, 255), Color.WHITE);

        agregarBoton("π", 18, new Color(77, 77, 77), Color.WHITE);
        agregarBoton("0", 18, new Color(77, 77, 77), Color.WHITE);
        agregarBoton(".", 18, new Color(77, 77, 77), Color.WHITE);
        agregarBoton("ANS", 18, new Color(0, 220, 235), Color.WHITE);

        agregarBoton("+", 18, new Color(0, 220, 235), Color.WHITE);
        agregarBoton("-", 18, new Color(0, 220, 235), Color.WHITE);
        agregarBoton("*", 18, new Color(0, 220, 235), Color.WHITE);
        agregarBoton("/", 18, new Color(0, 220, 235), Color.WHITE);

        agregarBoton("(", 18, new Color(0, 220, 235), Color.WHITE);
        agregarBoton(")", 18, new Color(0, 220, 235), Color.WHITE);
        agregarBoton("√", 18, new Color(0, 220, 235), Color.WHITE);
        agregarBoton("^", 18, new Color(0, 220, 235), Color.WHITE);
    }

    private void agregarBoton(String texto, int tamanoFuente, Color fondo, Color fuente) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Segoe UI", Font.PLAIN, tamanoFuente));
        boton.setBackground(fondo);
        boton.setForeground(fuente);
        boton.setBorderPainted(false);
        boton.setFocusPainted(false);
        boton.addActionListener(new ManejarBoton());

        boton.setBorder(null);
		boton.setFocusPainted(false);
		Color normalColor = boton.getBackground();
		int rojo = normalColor.getRed();
		int verde = normalColor.getGreen();
		int azul = normalColor.getBlue();
		int rojoN = rojo + 30;
		int verdeN = verde + 30;
		int azulN = azul + 30;
		if(rojoN > 255)
		{
			rojoN = 255;
		}
		if(verdeN > 255)
		{
			verdeN = 255;
		}
		if(azulN > 255)
		{
			azulN = 255;
		}
		
        Color hoverColor = new Color(rojoN, verdeN, azulN);
        
    	boton.addMouseListener(new MouseAdapter() {
            Timer enterTimer;
            Timer exitTimer;

            public void mouseEntered(MouseEvent e) {
                if (exitTimer != null && exitTimer.isRunning()) {
                    exitTimer.stop();
                }
                enterTimer = createColorTransitionTimer(boton, normalColor, hoverColor);
                enterTimer.start();
            }

            public void mouseExited(MouseEvent e) {
                if (enterTimer != null && enterTimer.isRunning()) {
                    enterTimer.stop();
                }
                exitTimer = createColorTransitionTimer(boton, hoverColor, normalColor);
                exitTimer.start();
            }
    	});

        panelNumerico.add(boton);
    }
    private static Timer createColorTransitionTimer(JButton button, Color startColor, Color endColor) {
        return new Timer(ANIMATION_DELAY, null) {
			private static final long serialVersionUID = -4701965186790357155L;
			long startTime = System.currentTimeMillis();

            {
                addActionListener(e -> {
                    long elapsed = System.currentTimeMillis() - startTime;
                    float progress = Math.min(1.0f, (float) elapsed / ANIMATION_DURATION);
                    button.setBackground(interpolateColor(startColor, endColor, progress));
                    if (progress >= 1.0f) {
                        ((Timer) e.getSource()).stop();
                    }
                });
            }
        };
    }

    private static Color interpolateColor(Color startColor, Color endColor, float fraction) {
        int red = (int) (startColor.getRed() + (endColor.getRed() - startColor.getRed()) * fraction);
        int green = (int) (startColor.getGreen() + (endColor.getGreen() - startColor.getGreen()) * fraction);
        int blue = (int) (startColor.getBlue() + (endColor.getBlue() - startColor.getBlue()) * fraction);
        return new Color(red, green, blue);
    }
    private class ManejarBoton implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String comando = e.getActionCommand();

            if (resultadoMostrado && !"C".equals(comando) && !"DEL".equals(comando) && !"↑".equals(comando) && !"↓".equals(comando)) {
                pantalla.setText("0");
                resultadoMostrado = false;
            }

            int posicionActual = pantalla.getCaretPosition();
            StringBuilder textoActual = new StringBuilder(pantalla.getText());

            switch (comando) {
                case "=":
                    evaluarExpresionPantalla();
                    break;
                case "C":
                    pantalla.setText("0");
                    break;
                case "DEL":
                    if (posicionActual > 0) {
                        if (posicionActual >= 3 && textoActual.substring(posicionActual - 3, posicionActual).equals("ANS")) {
                            textoActual.delete(posicionActual - 3, posicionActual);
                            pantalla.setText(textoActual.toString());
                            pantalla.setCaretPosition(posicionActual - 3);
                        } else {
                            textoActual.deleteCharAt(posicionActual - 1);
                            pantalla.setText(textoActual.toString());
                            pantalla.setCaretPosition(posicionActual - 1);
                        }
                    }
                    if (pantalla.getText().isEmpty()) {
                        pantalla.setText("0");
                    }
                    break;

                case "ANS":
                    pantalla.setText(pantalla.getText() + "ANS");
                    break;
                case "π":
                    if (textoActual.toString().equals("0")) {
                        pantalla.setText("π");
                    } else {
                        textoActual.insert(posicionActual, "π");
                        pantalla.setText(textoActual.toString());
                        pantalla.setCaretPosition(posicionActual + 1);
                    }
                    break;
                case "√":
                	 if (textoActual.toString().equals("0")) {
                         pantalla.setText("√");
                     } else {
                         textoActual.insert(posicionActual, "√");
                         pantalla.setText(textoActual.toString());
                         pantalla.setCaretPosition(posicionActual + 1);
                     }
                    break;
                default:
                    if (textoActual.toString().equals("0")) {
                        pantalla.setText(comando);
                    } else {
                        textoActual.insert(posicionActual, comando);
                        pantalla.setText(textoActual.toString());
                        pantalla.setCaretPosition(posicionActual + 1);
                    }
                    break;
            }

            actualizarCaretLabel();
        }
    }


    private class ManejarBotonHistorial implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String comando = e.getActionCommand();
            if (historial.isEmpty()) return;

            switch (comando) {
                case "↑":
                    if (indiceHistorial > 0) {
                        indiceHistorial--;
                        resultadoMostrado = false;
                        pantalla.setText(historial.get(indiceHistorial));
                    }
                    break;
                case "↓":
                    if (indiceHistorial < historial.size() - 1) {
                        indiceHistorial++;
                        resultadoMostrado = false;
                        pantalla.setText(historial.get(indiceHistorial));
                    }
                    break;
            }

            actualizarCaretLabel();
        }
    }

    private void evaluarExpresionPantalla() {
        String expresion = pantalla.getText();
        if (!expresion.isEmpty()) {
            try {
                String resultado = evaluar(expresion);
                double resultadoNumerico = Double.parseDouble(resultado);

                if (resultadoNumerico == (int) resultadoNumerico) {
                    pantalla.setText(String.valueOf((int) resultadoNumerico));
                } else {
                    pantalla.setText(resultado);
                }

                historial.add(expresion);
                indiceHistorial = historial.size();
                respuestaAnterior = resultadoNumerico;
                resultadoMostrado = true;
            } catch (ArithmeticException ex) {
                pantalla.setText("Error: División por 0");
                resultadoMostrado = true;
            } catch (Exception ex) {
                pantalla.setText("Error: Expresión inválida");
                resultadoMostrado = true;
            }
        }

        actualizarCaretLabel();
    }

    private double evaluarExpresion(List<String> postfijo) throws Exception {
        Stack<Double> pila = new Stack<>();
        for (String token : postfijo) {
            if (esOperador(token)) {
                if (token.equals("√")) {
                    if (pila.isEmpty()) {
                        throw new IllegalArgumentException("Expresión inválida: raíz cuadrada sin argumento.");
                    }
                    double b = pila.pop();
                    double resultadoRaiz = Math.sqrt(b);
                    pila.push(resultadoRaiz);
                } else { // Otros operadores como +, -, *, /, ^
                    double b = pila.pop();
                    double a = pila.pop();
                    switch (token) {
                        case "+":
                            pila.push(a + b);
                            break;
                        case "-":
                            pila.push(a - b);
                            break;
                        case "*":
                            pila.push(a * b);
                            break;
                        case "/":
                            if (b == 0) {
                                throw new ArithmeticException("División por cero.");
                            }
                            pila.push(a / b);
                            break;
                        case "^":
                            pila.push(Math.pow(a, b));
                            break;
                    }
                }
            } else {
                pila.push(Double.parseDouble(token));
            }
        }
        if (pila.size() != 1) {
            throw new IllegalArgumentException("Expresión inválida: falta operador.");
        }
        return pila.pop();
    }




    private String evaluar(String expresion) throws Exception {
        expresion = expresion.replaceAll("ANS", String.valueOf(respuestaAnterior));
        expresion = expresion.replaceAll("π", String.valueOf(PI));
        return Double.toString(evaluarExpresion(convertirPostfijo(expresion)));
    }

    private List<String> convertirPostfijo(String infijo) throws Exception {
        List<String> salida = new ArrayList<>();
        Stack<String> operadores = new Stack<>();
        StringBuilder numero = new StringBuilder();

        for (int i = 0; i < infijo.length(); i++) {
            char c = infijo.charAt(i);
            if (Character.isDigit(c) || c == '.') {
                numero.append(c);
            } else {
                if (numero.length() > 0) {
                    salida.add(numero.toString());
                    numero = new StringBuilder();
                }

                if (esOperador(String.valueOf(c)) || c == '(' || c == ')') {
                    if (c == '(') {
                        operadores.push(String.valueOf(c));
                    } else if (c == ')') {
                        while (!operadores.isEmpty() && !operadores.peek().equals("(")) {
                            salida.add(operadores.pop());
                        }
                        operadores.pop();
                    } else if (c == '√') { // Manejar la raíz cuadrada como operador unario
                        operadores.push(String.valueOf(c));
                    } else {
                        // Manejo de operadores binarios (+, -, *, /, ^) y signos menos unarios
                        if (c == '-' && (i == 0 || infijo.charAt(i - 1) == '(')) {
                            salida.add("0"); // Insertar un cero antes del número negativo
                        } else {
                            while (!operadores.isEmpty() && prioridad(operadores.peek()) >= prioridad(String.valueOf(c))) {
                                salida.add(operadores.pop());
                            }
                        }
                        operadores.push(String.valueOf(c));
                    }
                }
            }
        }

        if (numero.length() > 0) {
            salida.add(numero.toString());
        }

        while (!operadores.isEmpty()) {
            salida.add(operadores.pop());
        }

        return salida;
    }

    private boolean esOperador(String token) {
        return token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/") || token.equals("^");
    }

    private int prioridad(String operador) {
        switch (operador) {
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
                return 2;
            case "^":
                return 3;
            case "√":
                return 4; // Prioridad más alta para la raíz cuadrada
        }
        return -1;
    }

    public static void main(String[] args) {
        new Calculador_a();
    }
}
