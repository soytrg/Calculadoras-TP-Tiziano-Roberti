package gui;

import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.UIManager;

public class VentanaV5 extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	
	// 	variables for equation 1:
	private JTextField textfield_coeficiente_de_x_e1;
	private JTextField textfield_coeficiente_de_y_e1;
	private JTextField textfield_coeficiente_de_z_e1;
	private JTextField textfield_coeficiente_de_ti_e1;
	
	// 	variables for equation 2:
	private JTextField textfield_coeficiente_de_x_e2;
	private JTextField textfield_coeficiente_de_y_e2;
	private JTextField textfield_coeficiente_de_z_e2;
	private JTextField textfield_coeficiente_de_ti_e2;
	
	//variables for equation 3:
	private JTextField textfield_coeficiente_de_x_e3;
	private JTextField textfield_coeficiente_de_y_e3;
	private JTextField textfield_coeficiente_de_z_e3;
	private JTextField textfield_coeficiente_de_ti_e3;
	
	float x1,y1,z1,ti1;
	float x2,y2,z2,ti2;
	float x3,y3,z3,ti3;
	
	// variables for other things (functions, buttons inputs,focus keeper,etc)	
	String numeroIngresado = null;
	String last_focus = "xe1"; // First text field
	String boton;	
	int textfield_check=0;
	int decimal_verification[] = new int[12]; // To check whenever there its a "." already used in a text field
	int count_Focus = 0;
	int what_system = 2; // This indicates what system we are working at the moment, if 2x2, its = to 2, if 3x3 its = to 3
	private JButton boton_decimal;
	private JButton boton_signo;
	private static final int ANIMATION_DURATION = 250; // Duración de la animación en milisegundos
    private static final int ANIMATION_DELAY = 20; // Retraso entre cada paso de la animación en milisegundos

	// Results for the both variables
	float rtaX,rtaY,rtaZ,triangleX,triangle,triangleY,triangleZ;
	String mostrar_rtaX, mostrar_rtaY,mostrar_rtaZ;
	
	private final JPanel panel_2 = new JPanel();

	/**
	 * Create the frame.
	 */
	public VentanaV5() {
		
		UIManager.put("Button.disabledText", new Color(128,0,255));
		
		// General panel
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 600, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(51, 51, 51));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(51, 51, 51));
		panel.setBounds(150, 0, 300, 30);
		setLocationRelativeTo(null);
		setResizable(false);
		contentPane.add(panel);
		panel.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel lblNewLabel = new JLabel("Sistema de Ecuaciones");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblNewLabel);
		
		// 1st panel
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(51, 51, 51));
		panel_1.setBounds(42, 40, 501, 118);
		contentPane.add(panel_1);
		panel_1.setLayout(new GridLayout(3, 1, 0, 2));
		
		// 5th panel 
		// first equation
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(new Color(51, 51, 51));
		panel_1.add(panel_5);
		panel_5.setLayout(new GridLayout(0, 10, 5, 0));
		
		textfield_coeficiente_de_x_e1 = new JTextField();
		textfield_coeficiente_de_x_e1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		textfield_coeficiente_de_x_e1.setBackground(new Color(51, 51, 51));
		textfield_coeficiente_de_x_e1.setForeground(new Color(255, 255, 255));
		textfield_coeficiente_de_x_e1.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_x_e1.setColumns(2);
		textfield_coeficiente_de_x_e1.setFocusable(false);
		panel_5.add(textfield_coeficiente_de_x_e1);

		JLabel lblNewLabel_1 = new JLabel("X");
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		panel_5.add(lblNewLabel_1);
		
		JLabel lblNewLabel_4 = new JLabel("+");
		lblNewLabel_4.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.LEFT);
		panel_5.add(lblNewLabel_4);
		
		textfield_coeficiente_de_y_e1 = new JTextField();
		textfield_coeficiente_de_y_e1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		textfield_coeficiente_de_y_e1.setBackground(new Color(51, 51, 51));
		textfield_coeficiente_de_y_e1.setForeground(new Color(255, 255, 255));
		textfield_coeficiente_de_y_e1.setEditable(false);
		textfield_coeficiente_de_y_e1.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_y_e1.setColumns(10);
		textfield_coeficiente_de_y_e1.setFocusable(false);
		panel_5.add(textfield_coeficiente_de_y_e1);

		JLabel lblNewLabel_2 = new JLabel("Y");
		lblNewLabel_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
		panel_5.add(lblNewLabel_2);
		
		JLabel lblNewLabel_6 = new JLabel("+");
		lblNewLabel_6.setEnabled(false);
		
		lblNewLabel_6.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblNewLabel_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.LEFT);
		panel_5.add(lblNewLabel_6);
		
		textfield_coeficiente_de_z_e1 = new JTextField();
		textfield_coeficiente_de_z_e1.setEnabled(false);
		textfield_coeficiente_de_z_e1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		textfield_coeficiente_de_z_e1.setBackground(new Color(51, 51, 51));
		textfield_coeficiente_de_z_e1.setForeground(new Color(255, 255, 255));
		textfield_coeficiente_de_z_e1.setEditable(false);
		textfield_coeficiente_de_z_e1.setFocusable(false);
		textfield_coeficiente_de_z_e1.setHorizontalAlignment(SwingConstants.RIGHT);
		panel_5.add(textfield_coeficiente_de_z_e1);
		textfield_coeficiente_de_z_e1.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel("Z");
		lblNewLabel_3.setEnabled(false);
		lblNewLabel_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		panel_5.add(lblNewLabel_3);
		
		JLabel lblNewLabel_5 = new JLabel("=");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_5.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		panel_5.add(lblNewLabel_5);
		
		textfield_coeficiente_de_ti_e1 = new JTextField();
		textfield_coeficiente_de_ti_e1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		textfield_coeficiente_de_ti_e1.setBackground(new Color(51, 51, 51));
		textfield_coeficiente_de_ti_e1.setForeground(new Color(255, 255, 255));
		textfield_coeficiente_de_ti_e1.setEditable(false);
		textfield_coeficiente_de_ti_e1.setFocusable(false);
		textfield_coeficiente_de_ti_e1.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_ti_e1.setColumns(10);
		panel_5.add(textfield_coeficiente_de_ti_e1);

		// 6th panel
		// 2nd equation
		JPanel panel_6 = new JPanel();
		panel_6.setBackground(new Color(51, 51, 51));
		panel_1.add(panel_6);
		panel_6.setLayout(new GridLayout(0, 10, 5, 0));
		
		textfield_coeficiente_de_x_e2 = new JTextField();
		textfield_coeficiente_de_x_e2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		textfield_coeficiente_de_x_e2.setForeground(new Color(255, 255, 255));
		textfield_coeficiente_de_x_e2.setBackground(new Color(51, 51, 51));
		textfield_coeficiente_de_x_e2.setEditable(false);
		textfield_coeficiente_de_x_e2.setFocusable(false);
		textfield_coeficiente_de_x_e2.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_x_e2.setColumns(10);
		panel_6.add(textfield_coeficiente_de_x_e2);

		JLabel lblNewLabel_1_1 = new JLabel("X");
		lblNewLabel_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_1_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		panel_6.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_7 = new JLabel("+");
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_7.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblNewLabel_7.setForeground(new Color(255, 255, 255));
		panel_6.add(lblNewLabel_7);
		
		textfield_coeficiente_de_y_e2 = new JTextField();
		textfield_coeficiente_de_y_e2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		textfield_coeficiente_de_y_e2.setForeground(new Color(255, 255, 255));
		textfield_coeficiente_de_y_e2.setBackground(new Color(51, 51, 51));
		textfield_coeficiente_de_y_e2.setEditable(false);
		textfield_coeficiente_de_y_e2.setFocusable(false);
		textfield_coeficiente_de_y_e2.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_y_e2.setColumns(10);
		panel_6.add(textfield_coeficiente_de_y_e2);

		JLabel lblNewLabel_2_1 = new JLabel("Y");
		lblNewLabel_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_2_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.LEFT);
		panel_6.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_8 = new JLabel("+");
		lblNewLabel_8.setEnabled(false);
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_8.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblNewLabel_8.setForeground(new Color(255, 255, 255));
		panel_6.add(lblNewLabel_8);
		
		textfield_coeficiente_de_z_e2 = new JTextField();
		textfield_coeficiente_de_z_e2.setEnabled(false);
		textfield_coeficiente_de_z_e2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		textfield_coeficiente_de_z_e2.setForeground(new Color(255, 255, 255));
		textfield_coeficiente_de_z_e2.setBackground(new Color(51, 51, 51));
		textfield_coeficiente_de_z_e2.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_z_e2.setEditable(false);
		textfield_coeficiente_de_z_e2.setFocusable(false);
		textfield_coeficiente_de_z_e2.setColumns(10);
		panel_6.add(textfield_coeficiente_de_z_e2);
		
		JLabel lblNewLabel_3_2 = new JLabel("Z");
		lblNewLabel_3_2.setEnabled(false);
		lblNewLabel_3_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_3_2.setForeground(new Color(255, 255, 255));
		panel_6.add(lblNewLabel_3_2);
		
		JLabel lblNewLabel_9 = new JLabel("=");
		lblNewLabel_9.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_9.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblNewLabel_9.setForeground(new Color(255, 255, 255));
		panel_6.add(lblNewLabel_9);
		
		textfield_coeficiente_de_ti_e2 = new JTextField();
		textfield_coeficiente_de_ti_e2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		textfield_coeficiente_de_ti_e2.setForeground(new Color(255, 255, 255));
		textfield_coeficiente_de_ti_e2.setBackground(new Color(51, 51, 51));
		textfield_coeficiente_de_ti_e2.setEditable(false);
		textfield_coeficiente_de_ti_e2.setFocusable(false);
		textfield_coeficiente_de_ti_e2.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_ti_e2.setColumns(10);
		panel_6.add(textfield_coeficiente_de_ti_e2);
		
		// 8th panel
		// 3rd equation
		JPanel panel_8 = new JPanel();
		panel_8.setBackground(new Color(51, 51, 51));
		panel_1.add(panel_8);
		panel_8.setLayout(new GridLayout(0, 10, 5, 0));
		
		textfield_coeficiente_de_x_e3 = new JTextField();
		textfield_coeficiente_de_x_e3.setEnabled(false);
		textfield_coeficiente_de_x_e3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		textfield_coeficiente_de_x_e3.setForeground(new Color(255, 255, 255));
		textfield_coeficiente_de_x_e3.setBackground(new Color(51, 51, 51));
		textfield_coeficiente_de_x_e3.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_x_e3.setEditable(false);
		textfield_coeficiente_de_x_e3.setFocusable(false);
		textfield_coeficiente_de_x_e3.setColumns(10);
		panel_8.add(textfield_coeficiente_de_x_e3);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("X");
		lblNewLabel_1_1_1.setEnabled(false);
		lblNewLabel_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_1_1_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		panel_8.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_10 = new JLabel("+");
		lblNewLabel_10.setEnabled(false);
		lblNewLabel_10.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_10.setForeground(new Color(255, 255, 255));
		panel_8.add(lblNewLabel_10);
		
		textfield_coeficiente_de_y_e3 = new JTextField();
		textfield_coeficiente_de_y_e3.setEnabled(false);
		textfield_coeficiente_de_y_e3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		textfield_coeficiente_de_y_e3.setForeground(new Color(255, 255, 255));
		textfield_coeficiente_de_y_e3.setBackground(new Color(51, 51, 51));
		textfield_coeficiente_de_y_e3.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_y_e3.setEditable(false);
		textfield_coeficiente_de_y_e3.setFocusable(false);
		textfield_coeficiente_de_y_e3.setColumns(10);
		panel_8.add(textfield_coeficiente_de_y_e3);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Y");
		lblNewLabel_2_1_1.setEnabled(false);
		lblNewLabel_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_2_1_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_2_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		panel_8.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_11 = new JLabel("+");
		lblNewLabel_11.setEnabled(false);
		lblNewLabel_11.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblNewLabel_11.setForeground(new Color(255, 255, 255));
		lblNewLabel_11.setHorizontalAlignment(SwingConstants.LEFT);
		panel_8.add(lblNewLabel_11);
		
		textfield_coeficiente_de_z_e3 = new JTextField();
		textfield_coeficiente_de_z_e3.setEnabled(false);
		textfield_coeficiente_de_z_e3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		textfield_coeficiente_de_z_e3.setForeground(new Color(255, 255, 255));
		textfield_coeficiente_de_z_e3.setBackground(new Color(51, 51, 51));
		textfield_coeficiente_de_z_e3.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_z_e3.setEditable(false);
		textfield_coeficiente_de_z_e3.setFocusable(false);
		textfield_coeficiente_de_z_e3.setColumns(10);
		panel_8.add(textfield_coeficiente_de_z_e3);
		
		JLabel lblNewLabel_3_2_1 = new JLabel("Z");
		lblNewLabel_3_2_1.setEnabled(false);
		lblNewLabel_3_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_3_2_1.setForeground(new Color(255, 255, 255));
		panel_8.add(lblNewLabel_3_2_1);
		
		JLabel lblNewLabel_12 = new JLabel("=");
		lblNewLabel_12.setEnabled(false);
		lblNewLabel_12.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_12.setForeground(new Color(255, 255, 255));
		lblNewLabel_12.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		panel_8.add(lblNewLabel_12);
		
		textfield_coeficiente_de_ti_e3 = new JTextField();
		textfield_coeficiente_de_ti_e3.setEnabled(false);
		textfield_coeficiente_de_ti_e3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		textfield_coeficiente_de_ti_e3.setForeground(new Color(255, 255, 255));
		textfield_coeficiente_de_ti_e3.setBackground(new Color(51, 51, 51));
		textfield_coeficiente_de_ti_e3.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_ti_e3.setEditable(false);
		textfield_coeficiente_de_ti_e3.setFocusable(false);
		textfield_coeficiente_de_ti_e3.setColumns(10);
		panel_8.add(textfield_coeficiente_de_ti_e3);

		//7th Panel
		// Results of the variables will be shown here:
		JPanel panel_7 = new JPanel();
		panel_7.setBackground(new Color(51, 51, 51));
		panel_7.setBounds(150, 160, 270, 70);
		contentPane.add(panel_7);
		panel_7.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel lbResultado = new JLabel("Resultados:");
		lbResultado.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lbResultado.setBackground(new Color(77, 77, 77));
		lbResultado.setForeground(new Color(255, 255, 255));
		lbResultado.setHorizontalAlignment(SwingConstants.CENTER);
		panel_7.add(lbResultado);
		panel_2.setBackground(new Color(51, 51, 51));
		
		// 2nd panel
		// Buttons for 2x2 system equation calculator and 3x3
		panel_2.setBounds(-10, 242, 594, 56);
		contentPane.add(panel_2);
		
		// 2x2:
		JButton btn2x2 = new JButton("2x2");
		btn2x2.setToolTipText("Sistema de Ecuaciones 2x2");
		btn2x2.setEnabled(false);
		btn2x2.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btn2x2.setForeground(new Color(255, 255, 255));
		btn2x2.setBackground(new Color(0, 150, 255));
		btn2x2.setBorderPainted(false);
		btn2x2.setFocusPainted(false); 
		btn2x2.setFocusable(false);
		panel_2.setLayout(new GridLayout(0, 2, 1, 1));
		panel_2.add(btn2x2);
		hover(btn2x2);
		
		// 3x3:
		JButton btn3x3 = new JButton("3x3");
		btn3x3.setToolTipText("Sistema de Ecuaciones 3x3");
		btn3x3.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btn3x3.setForeground(new Color(255, 255, 255));
		btn3x3.setBackground(new Color(0, 150, 255));
		btn3x3.setBorderPainted(false);
		btn3x3.setFocusPainted(false);
		btn3x3.setFocusable(false);
		hover(btn3x3);
		panel_2.add(btn3x3);
		
		// 2x2 function
		btn2x2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				what_system = 2;
				last_focus = "xe1";
				count_Focus = 0;
				btn2x2.setEnabled(false);
				btn3x3.setEnabled(true);
				
				textfield_coeficiente_de_x_e1.setEditable(true);
				textfield_coeficiente_de_y_e1.setEditable(false);
				textfield_coeficiente_de_z_e1.setEditable(false);
				textfield_coeficiente_de_ti_e1.setEditable(false);
								  
				textfield_coeficiente_de_x_e2.setEditable(false);
				textfield_coeficiente_de_y_e2.setEditable(false);
				textfield_coeficiente_de_z_e2.setEditable(false);
				textfield_coeficiente_de_ti_e2.setEditable(false);
				
				textfield_coeficiente_de_x_e3.setEditable(false);
				textfield_coeficiente_de_y_e3.setEditable(false);
				textfield_coeficiente_de_z_e3.setEditable(false);
				textfield_coeficiente_de_ti_e3.setEditable(false);
				
				lblNewLabel_6.setEnabled(false);
				textfield_coeficiente_de_z_e1.setEnabled(false);
				lblNewLabel_3.setEnabled(false);
				
				lblNewLabel_8.setEnabled(false);
				textfield_coeficiente_de_z_e2.setEnabled(false);
				lblNewLabel_3_2.setEnabled(false);
				
				textfield_coeficiente_de_x_e3.setEnabled(false);
				lblNewLabel_1_1_1.setEnabled(false);
				lblNewLabel_10.setEnabled(false);
				
				textfield_coeficiente_de_y_e3.setEnabled(false);
				lblNewLabel_2_1_1.setEnabled(false);
				lblNewLabel_11.setEnabled(false);
				
				textfield_coeficiente_de_z_e3.setEnabled(false);
				lblNewLabel_3_2_1.setEnabled(false);
				lblNewLabel_12.setEnabled(false);
				textfield_coeficiente_de_ti_e3.setEnabled(false);
				
				textfield_coeficiente_de_z_e1.setText(null);
				textfield_coeficiente_de_z_e2.setText(null);
				textfield_coeficiente_de_x_e3.setText(null);
				textfield_coeficiente_de_y_e3.setText(null);
				textfield_coeficiente_de_z_e3.setText(null);
				textfield_coeficiente_de_ti_e3.setText(null);
			}
		});
		
		// 3x3 Function
		btn3x3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				what_system = 3;
				last_focus = "xe1";
				count_Focus = 0;
				btn2x2.setEnabled(true);
				btn3x3.setEnabled(false);
				
				textfield_coeficiente_de_x_e1.setEditable(true);
				textfield_coeficiente_de_y_e1.setEditable(false);
				textfield_coeficiente_de_z_e1.setEditable(false);
				textfield_coeficiente_de_ti_e1.setEditable(false);
								  
				textfield_coeficiente_de_x_e2.setEditable(false);
				textfield_coeficiente_de_y_e2.setEditable(false);
				textfield_coeficiente_de_z_e2.setEditable(false);
				textfield_coeficiente_de_ti_e2.setEditable(false);
				
				textfield_coeficiente_de_x_e3.setEditable(false);
				textfield_coeficiente_de_y_e3.setEditable(false);
				textfield_coeficiente_de_z_e3.setEditable(false);
				textfield_coeficiente_de_ti_e3.setEditable(false);
				
				lblNewLabel_6.setEnabled(true);
				textfield_coeficiente_de_z_e1.setEnabled(true);
				lblNewLabel_3.setEnabled(true);
				
				lblNewLabel_8.setEnabled(true);
				textfield_coeficiente_de_z_e2.setEnabled(true);
				lblNewLabel_3_2.setEnabled(true);
				
				textfield_coeficiente_de_x_e3.setEnabled(true);
				lblNewLabel_1_1_1.setEnabled(true);
				lblNewLabel_10.setEnabled(true);
				
				textfield_coeficiente_de_y_e3.setEnabled(true);
				lblNewLabel_2_1_1.setEnabled(true);
				lblNewLabel_11.setEnabled(true);
				
				textfield_coeficiente_de_z_e3.setEnabled(true);
				lblNewLabel_3_2_1.setEnabled(true);
				lblNewLabel_12.setEnabled(true);
				textfield_coeficiente_de_ti_e3.setEnabled(true);
			}
		});
		
		// 3rd panel
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(51, 51, 51));
		panel_3.setBounds(42, 331, 341, 300);
		contentPane.add(panel_3);
		panel_3.setLayout(new GridLayout(0, 3, 1, 1));
		
		// Calculator buttons 1,2,3,4,5,6,7,8,9,0,+/-,.
		// 7
		JButton btn7 = new JButton("7");
		btn7.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btn7.setForeground(new Color(255, 255, 255));
		btn7.setBackground(new Color(77, 77, 77));
		btn7.setBorderPainted(false);
		btn7.setFocusPainted(false);
		btn7.setFocusable(false);
		hover(btn7);
		btn7.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = "7";
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn7);
		
		// 8
		JButton btn8 = new JButton("8");
		btn8.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btn8.setForeground(new Color(255, 255, 255));
		btn8.setBackground(new Color(77, 77, 77));
		btn8.setBorderPainted(false);
		btn8.setFocusPainted(false);
		btn8.setFocusable(false);
		hover(btn8);
		btn8.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = "8";
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn8);
		
		// 9
		JButton btn9 = new JButton("9");
		btn9.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btn9.setForeground(new Color(255, 255, 255));
		btn9.setBackground(new Color(77, 77, 77));
		btn9.setBorderPainted(false);
		btn9.setFocusPainted(false);
		btn9.setFocusable(false);
		hover(btn9);
		btn9.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = "9";
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn9);
		
		// 4
		JButton btn4 = new JButton("4");
		btn4.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btn4.setForeground(new Color(255, 255, 255));
		btn4.setBackground(new Color(77, 77, 77));
		btn4.setBorderPainted(false);
		btn4.setFocusPainted(false);
		btn4.setFocusable(false);
		hover(btn4);
		btn4.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = "4";
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn4);
		
		// 5
		JButton btn5 = new JButton("5");
		btn5.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btn5.setForeground(new Color(255, 255, 255));
		btn5.setBackground(new Color(77, 77, 77));
		btn5.setBorderPainted(false);
		btn5.setFocusPainted(false);	
		btn5.setFocusable(false);
		hover(btn5);
		btn5.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = "5";
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn5);
		
		// 6
		JButton btn6 = new JButton("6");
		btn6.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btn6.setForeground(new Color(255, 255, 255));
		btn6.setBackground(new Color(77, 77, 77));
		btn6.setBorderPainted(false);
		btn6.setFocusPainted(false);
		btn6.setFocusable(false);
		hover(btn6);
		btn6.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = "6";
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn6);
		
		// 1
		JButton btn1 = new JButton("1");
		btn1.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btn1.setForeground(new Color(255, 255, 255));
		btn1.setBackground(new Color(77, 77, 77));
		btn1.setBorderPainted(false);
		btn1.setFocusPainted(false);
		btn1.setFocusable(false);
		hover(btn1);
		btn1.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = "1";
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn1);
		
		// 2
		JButton btn2 = new JButton("2");
		btn2.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btn2.setForeground(new Color(255, 255, 255));
		btn2.setBackground(new Color(77, 77, 77));
		btn2.setBorderPainted(false);
		btn2.setFocusPainted(false);
		btn2.setFocusable(false);
		hover(btn2);
		btn2.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = "2";
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn2);
		
		// 3
		JButton btn3 = new JButton("3");
		btn3.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btn3.setForeground(new Color(255, 255, 255));
		btn3.setBackground(new Color(77, 77, 77));
		btn3.setBorderPainted(false);
		btn3.setFocusPainted(false);
		btn3.setFocusable(false);
		hover(btn3);
		btn3.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = "3";
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn3);
		
		// +/-
		JButton btnCambioSigno = new JButton("+/-");
		btnCambioSigno.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btnCambioSigno.setForeground(new Color(255, 255, 255));
		btnCambioSigno.setBackground(new Color(77, 77, 77));
		panel_3.add(btnCambioSigno);
		hover(btnCambioSigno);
		btnCambioSigno.setBorderPainted(false);
		btnCambioSigno.setFocusPainted(false);
		btnCambioSigno.setFocusable(false);
		btnCambioSigno.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = "-";
				funcionalidad_botones(boton, last_focus);
				cambio_de_signo_verification(last_focus);
			}
		});
		
		boton_signo = btnCambioSigno;
		
		// 0
		JButton btn0 = new JButton("0");
		btn0.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btn0.setForeground(new Color(255, 255, 255));
		btn0.setBackground(new Color(77, 77, 77));
		btn0.setBorderPainted(false);
		btn0.setFocusPainted(false);
		btn0.setFocusable(false);
		hover(btn0);
		btn0.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = "0";
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn0);
		
		// .
		JButton btnDecimal = new JButton(".");
		btnDecimal.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btnDecimal.setForeground(new Color(255, 255, 255));
		btnDecimal.setBackground(new Color(77, 77, 77));
		panel_3.add(btnDecimal);
		hover(btnDecimal);
		btnDecimal.setBorderPainted(false);
		btnDecimal.setFocusPainted(false);
		btnDecimal.setFocusable(false);
		btnDecimal.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton= ".";
				funcionalidad_botones(boton,last_focus);
				point_verification(last_focus);
			}
		});		
		
		boton_decimal = btnDecimal;
		
		
		// 4rd panel:
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(new Color(51, 51, 51));
		panel_4.setBounds(393, 331, 150, 300);
		contentPane.add(panel_4);
		panel_4.setLayout(new GridLayout(4, 1, 1, 1));
		
		// Resolve button and Delete button
		// delete button
		JButton btnDel = new JButton("DEL");
		btnDel.setForeground(new Color(255, 255, 255));
		btnDel.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btnDel.setBackground(new Color(0, 150, 255));
		panel_4.add(btnDel);
		hover(btnDel);
		btnDel.setBorderPainted(false);
		btnDel.setFocusPainted(false); 
		btnDel.setFocusable(false);
		btnDel.addActionListener(new ActionListener() 
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				switch(last_focus)
				{
				case "xe1":
						del_button(textfield_coeficiente_de_x_e1, numeroIngresado);
					break;
					
				case "ye1":
					del_button(textfield_coeficiente_de_y_e1, numeroIngresado);
					break;
					
				case "ze1":
					del_button(textfield_coeficiente_de_z_e1, numeroIngresado);
					 break;
					 
				case "tie1":
					del_button(textfield_coeficiente_de_ti_e1, numeroIngresado);
					break;
					
				case "xe2":
					del_button(textfield_coeficiente_de_x_e2, numeroIngresado);
					break;
					
				case "ye2":
					del_button(textfield_coeficiente_de_y_e2, numeroIngresado);
					break;
					
				case "ze2":
					del_button(textfield_coeficiente_de_z_e2, numeroIngresado);
					break;	 
					
				case "tie2":
					del_button(textfield_coeficiente_de_ti_e2, numeroIngresado);
					break;
					
				case "xe3":
					del_button(textfield_coeficiente_de_x_e3, numeroIngresado);
					break;
					
				case "ye3":
					del_button(textfield_coeficiente_de_y_e3, numeroIngresado);
					break;
				case "ze3":
					del_button(textfield_coeficiente_de_z_e3, numeroIngresado);
					 break;
					 
				case "tie3":
					del_button(textfield_coeficiente_de_ti_e3, numeroIngresado);
					break;
				}
				point_verification(last_focus);
				cambio_de_signo_verification(last_focus);
				lbResultado.setText("");
			}
		});

		JButton btnMoverse_ala_derecha = new JButton(">>>");
		btnMoverse_ala_derecha.setForeground(new Color(255, 255, 255));
		btnMoverse_ala_derecha.setToolTipText("Siguiente componente");
		btnMoverse_ala_derecha.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btnMoverse_ala_derecha.setBackground(new Color(0, 150, 255));
		panel_4.add(btnMoverse_ala_derecha);
		hover(btnMoverse_ala_derecha);
		btnMoverse_ala_derecha.setBorderPainted(false);
		btnMoverse_ala_derecha.setFocusPainted(false); 
		btnMoverse_ala_derecha.setFocusable(false);
		btnMoverse_ala_derecha.addActionListener(new ActionListener() 
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{				
				switch(count_Focus)
				{
					case 0:
						count_Focus++; // 0 + 1 = 1
						last_focus = "ye1";
						textfield_coeficiente_de_x_e1.setEditable(false);
						textfield_coeficiente_de_y_e1.setEditable(true);
						break;
					case 1:
						if(what_system == 3)
						{
							count_Focus++; // 1 + 1 = 2
							last_focus = "ze1";
							textfield_coeficiente_de_y_e1.setEditable(false);
							textfield_coeficiente_de_z_e1.setEditable(true);
						}
						else
						{
							count_Focus++;	// = 2
							last_focus = "tie1";
							textfield_coeficiente_de_y_e1.setEditable(false);
							textfield_coeficiente_de_ti_e1.setEditable(true);
						}
						break;
					case 2:
						if(what_system == 3)
						{
							count_Focus++;	// = 3
							last_focus = "tie1";
							textfield_coeficiente_de_z_e1.setEditable(false);
							textfield_coeficiente_de_ti_e1.setEditable(true);
						}
						else
						{
							count_Focus++; // = 3
							last_focus = "xe2";
							textfield_coeficiente_de_ti_e1.setEditable(false);
							textfield_coeficiente_de_x_e2.setEditable(true);
						}
						break;
					case 3:
						if(what_system == 3)
						{
							count_Focus++; // = 4
							last_focus = "xe2";
							textfield_coeficiente_de_ti_e1.setEditable(false);
							textfield_coeficiente_de_x_e2.setEditable(true);
						}
						else
						{
							count_Focus++; // = 4
							last_focus = "ye2";
							textfield_coeficiente_de_x_e2.setEditable(false);
							textfield_coeficiente_de_y_e2.setEditable(true);
						}
						break;
					case 4:
						if(what_system == 3)
						{
							count_Focus++; // = 5
							last_focus = "ye2";
							textfield_coeficiente_de_x_e2.setEditable(false);
							textfield_coeficiente_de_y_e2.setEditable(true);
						}
						else
						{
							count_Focus++; // = 5
							last_focus = "tie2";
							textfield_coeficiente_de_y_e2.setEditable(false);
							textfield_coeficiente_de_ti_e2.setEditable(true);
						}
						break;
					case 5:
						if(what_system == 3)
						{
							count_Focus++; // = 6
							last_focus = "ze2";
							textfield_coeficiente_de_y_e2.setEditable(false);
							textfield_coeficiente_de_z_e2.setEditable(true);
						}
						else
						{
							count_Focus=0; // = 0
							last_focus = "xe1";
							textfield_coeficiente_de_ti_e2.setEditable(false);
							textfield_coeficiente_de_x_e1.setEditable(true);
						}
						break; 
					case 6:
						count_Focus++; // = 7
						last_focus = "tie2";
						textfield_coeficiente_de_z_e2.setEditable(false);
						textfield_coeficiente_de_ti_e2.setEditable(true);
						break;
					case 7:
						count_Focus++; // = 8
						last_focus = "xe3";
						textfield_coeficiente_de_ti_e2.setEditable(false);
						textfield_coeficiente_de_x_e3.setEditable(true);
						break;
					case 8:
						count_Focus++; // = 9
						last_focus = "ye3";
						textfield_coeficiente_de_x_e3.setEditable(false);
						textfield_coeficiente_de_y_e3.setEditable(true);
						break;
					case 9:
						count_Focus++;
						last_focus = "ze3";
						textfield_coeficiente_de_y_e3.setEditable(false);
						textfield_coeficiente_de_z_e3.setEditable(true);
						break;	
					case 10:
						count_Focus++;
						last_focus = "tie3";
						textfield_coeficiente_de_z_e3.setEditable(false);
						textfield_coeficiente_de_ti_e3.setEditable(true);
						break;	
					case 11:
						count_Focus=0;
						last_focus = "xe1";
						textfield_coeficiente_de_ti_e3.setEditable(false);
						textfield_coeficiente_de_x_e1.setEditable(true);
						break;	
				}
				point_verification(last_focus);
				cambio_de_signo_verification(last_focus);
			}
		});
		
		//Clear button
		JButton btnClear = new JButton("C");
		btnClear.setForeground(new Color(255, 255, 255));
		btnClear.setBackground(new Color(0, 150, 255));
		btnClear.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		panel_4.add(btnClear);
		btnClear.setBorderPainted(false);
		btnClear.setFocusPainted(false); 
		btnClear.setFocusable(false);
		hover(btnClear);
		btnClear.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				textfield_coeficiente_de_x_e1.setText(null);
				textfield_coeficiente_de_y_e1.setText(null);
				textfield_coeficiente_de_z_e1.setText(null);
				textfield_coeficiente_de_ti_e1.setText(null);
				
				textfield_coeficiente_de_x_e2.setText(null);
				textfield_coeficiente_de_y_e2.setText(null);
				textfield_coeficiente_de_z_e2.setText(null);
				textfield_coeficiente_de_ti_e2.setText(null);
				
				textfield_coeficiente_de_x_e3.setText(null);
				textfield_coeficiente_de_y_e3.setText(null);
				textfield_coeficiente_de_z_e3.setText(null);
				textfield_coeficiente_de_ti_e3.setText(null);
				
				point_verification(last_focus);
				cambio_de_signo_verification(last_focus);
				lbResultado.setText("");
			}
		});
		
		// Resolve button
		JButton btnResolver = new JButton("Resolver");
		btnResolver.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btnResolver.setForeground(new Color(255, 255, 255));
		btnResolver.setBackground(new Color(0, 175, 255));
		panel_4.add(btnResolver);
		hover(btnResolver);
		btnResolver.setBorderPainted(false);
		btnResolver.setFocusPainted(false);
		btnResolver.setFocusable(false);
		
		btnResolver.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				// I will use the method of the determinants
				// 2x2:
				// source: https://www.youtube.com/watch?v=jZIk90KQo6s
				// 	X= TriangleX/Triangle;
				//	Y= TriangleY/Triangle;
				//	Triangle: (x1 * y2) - (x2 * y1);
				//  TriangleX: (ti1 * y2) - (ti2 * y1);
				// 	TriangleY: (x1 * ti2) - (x2 * ti1);
				
				//	3x3:
				//	source: https://www.youtube.com/watch?v=8Vx3KQj7bd0
				// 	X= TriangleX/Triangle;
				//	Y= TriangleY/Triangle;
				//  Z= TriangleZ/Triangle;
				//	Triangle:  ((xe1*ye2*ze3)+(xe2*ye3*ze1)+(xe3*ye1*ze2)) - ((ze1*ye2*xe3)+(ze2*ye3*xe1)+(ze3*ye1*xe2));
				// 	TriangleX: ((tie1*ye2*ze3)+(tie2*ye3*ze1)+(tie3*ye1*ze2)) - ((ze1*ye2*tie3)+(ze2*ye3*tie1)+(ze3*ye1*tie2));
				//	TriangleY: ((xe1*tie2*ze3)+(xe2*tie3*ze1)+(xe3*tie1*ze2)) - ((ze1*tie2*xe3)+(ze2*tie3*xe1)+(ze3*tie1*xe2));
				//	TriangleZ: ((xe1*ye2*tie3)+(xe2*ye3*tie1)+(xe3*ye1*tie2)) - ((tie1*ye2*xe3)+(tie2*ye3*xe1)+(tie3*ye1*xe2));
				
				lbResultado.setText("Resultados: ");
				
				text_field_verification(textfield_coeficiente_de_x_e1);
				text_field_verification(textfield_coeficiente_de_y_e1);
				text_field_verification(textfield_coeficiente_de_ti_e1);
				
				text_field_verification(textfield_coeficiente_de_x_e2);
				text_field_verification(textfield_coeficiente_de_y_e2);
				text_field_verification(textfield_coeficiente_de_ti_e2);
				
			
				if(textfield_check==0)
				{
					x1 = Float.parseFloat(textfield_coeficiente_de_x_e1.getText());
					y1 = Float.parseFloat(textfield_coeficiente_de_y_e1.getText());
					ti1 = Float.parseFloat(textfield_coeficiente_de_ti_e1.getText());
					
					x2 = Float.parseFloat(textfield_coeficiente_de_x_e2.getText());
					y2 = Float.parseFloat(textfield_coeficiente_de_y_e2.getText());
					ti2 = Float.parseFloat(textfield_coeficiente_de_ti_e2.getText());
					
							switch(what_system)
							{
							case 2:							
								lbResultado.setText("");
								
								triangle  = (x1 * y2) - (x2 * y1);
								
								if(triangle == 0)
								{
									numeroIngresado = "ERROR (No se puede dividir entre 0)";
									lbResultado.setText(numeroIngresado);
								}
								else
								{
									triangleX = (ti1 * y2) - (ti2 * y1);
									triangleY = (x1 * ti2) - (x2 * ti1);
									
									rtaX = triangleX/triangle;
									rtaY = triangleY/triangle;
									
									mostrar_rtaX= String.format("%.2f", rtaX);
									mostrar_rtaY= String.format("%.2f", rtaY);
									
									numeroIngresado = lbResultado.getText() + "Resultados: " + " X= " + mostrar_rtaX  + " Y= " + mostrar_rtaY;
									lbResultado.setText(numeroIngresado);
								}
								break;
							case 3:
									lbResultado.setText("");
									text_field_verification(textfield_coeficiente_de_z_e1);
									
									text_field_verification(textfield_coeficiente_de_z_e2);
									
									text_field_verification(textfield_coeficiente_de_x_e3);
									text_field_verification(textfield_coeficiente_de_y_e3);
									text_field_verification(textfield_coeficiente_de_z_e3);
									text_field_verification(textfield_coeficiente_de_ti_e3);
									
									if(textfield_check==0)
									{
										x3 = Float.parseFloat(textfield_coeficiente_de_x_e3.getText());
										y3 = Float.parseFloat(textfield_coeficiente_de_y_e3.getText());
										ti3 = Float.parseFloat(textfield_coeficiente_de_ti_e3.getText());
										
										z1 = Float.parseFloat(textfield_coeficiente_de_z_e1.getText());
										z2 = Float.parseFloat(textfield_coeficiente_de_z_e2.getText());
										z3 = Float.parseFloat(textfield_coeficiente_de_z_e3.getText());
										
										triangle = ((x1*y2*z3)+(x2*y3*z1)+(x3*y1*z2)) - ((z1*y2*x3)+(z2*y3*x1)+(z3*y1*x2));
			
										if(triangle == 0)
										{
											numeroIngresado = "ERROR (No se puede dividir entre 0)";
											lbResultado.setText(numeroIngresado);
										}
										else
										{
											triangleX= ((ti1*y2*z3)+(ti2*y3*z1)+(ti3*y1*z2)) - ((z1*y2*ti3)+(z2*y3*ti1)+(z3*y1*ti2));
											triangleY= ((x1*ti2*z3)+(x2*ti3*z1)+(x3*ti1*z2)) - ((z1*ti2*x3)+(z2*ti3*x1)+(z3*ti1*x2));
											triangleZ= ((x1*y2*ti3)+(x2*y3*ti1)+(x3*y1*ti2)) - ((ti1*y2*x3)+(ti2*y3*x1)+(ti3*y1*x2));
											
											rtaX = triangleX/triangle;
											rtaY = triangleY/triangle;
											rtaZ = triangleZ/triangle;
											
											mostrar_rtaX= String.format("%.2f", rtaX);
											mostrar_rtaY= String.format("%.2f", rtaY);
											mostrar_rtaZ= String.format("%.2f", rtaZ);
											
											numeroIngresado = lbResultado.getText() + "Resultados: " + " X= " + mostrar_rtaX  + " Y= " + mostrar_rtaY + " Z= " + mostrar_rtaZ;
											lbResultado.setText(numeroIngresado);
										} 
									}
									else
									{
								 		lbResultado.setText("Ingrese valores validos.");
								 		textfield_check = 0;
									}
								break;
							}
					}
					else
					{
						lbResultado.setText("Ingrese valores validos.");
				 		textfield_check = 0;
					}
				}
		
		});
		
		//Button to go to the main menu
		JButton btn_Volver_al_menu = new JButton("Volver");
		btn_Volver_al_menu.setForeground(new Color(255, 255, 255));
		btn_Volver_al_menu.setBackground(new Color(77, 77, 77));
		btn_Volver_al_menu.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		btn_Volver_al_menu.setBorderPainted(false);
		btn_Volver_al_menu.setFocusPainted(false); 
		btn_Volver_al_menu.setFocusable(false);
		hover(btn_Volver_al_menu);
		btn_Volver_al_menu.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				dispose();
			}
		});
		btn_Volver_al_menu.setBounds(0, 0, 89, 23);
		contentPane.add(btn_Volver_al_menu);
		
		setTitle("Calculadora Sistema de Ecuaciones");
	}
	
	// Puts the users input on the screen
	private void funcionalidad_botones(String boton, String lastFocus)
	{
		switch(boton)
		{
		case ".":
			focus_keeper(boton,lastFocus);
			break;
		case "-":
			focus_keeper(boton,lastFocus);
			break;
		case "0":
			focus_keeper(boton,lastFocus);
			break;
		case "1":
			focus_keeper(boton,lastFocus);
			break;
		case "2":
			focus_keeper(boton,lastFocus);
			break;
		case "3":
			focus_keeper(boton,lastFocus);
			break;
		case "4":
			focus_keeper(boton,lastFocus);
			break;		
		case "5":
			focus_keeper(boton,lastFocus);
			break;
		case "6":
			focus_keeper(boton,lastFocus);
			break;
		case "7":
			focus_keeper(boton,lastFocus);
			break;
		case "8":
			focus_keeper(boton,lastFocus);
			break;
		case "9":
			focus_keeper(boton,lastFocus);
			break;
		}
	}
	
	// Keeps track of the focus of where the user wants to put his input
	private void focus_keeper(String boton, String lastfocus)
	{
		if(boton != "-")
		{
			switch(lastfocus)
			{
			case "xe1":
				 numeroIngresado = textfield_coeficiente_de_x_e1.getText() + boton;
				 textfield_coeficiente_de_x_e1.setText(numeroIngresado);
				break;
			case "ye1":
				numeroIngresado = textfield_coeficiente_de_y_e1.getText() + boton;
				textfield_coeficiente_de_y_e1.setText(numeroIngresado);
				break;
			case "ze1":
				 numeroIngresado = textfield_coeficiente_de_z_e1.getText() + boton;
				 textfield_coeficiente_de_z_e1.setText(numeroIngresado);
				 break;
			case "tie1":
				numeroIngresado = textfield_coeficiente_de_ti_e1.getText() + boton;
				textfield_coeficiente_de_ti_e1.setText(numeroIngresado);
				break;
			case "xe2":
				numeroIngresado = textfield_coeficiente_de_x_e2.getText() + boton;
				textfield_coeficiente_de_x_e2.setText(numeroIngresado);
				break;
			case "ye2":
				numeroIngresado = textfield_coeficiente_de_y_e2.getText() + boton;
				textfield_coeficiente_de_y_e2.setText(numeroIngresado);
				break;
			case "ze2":
				 numeroIngresado = textfield_coeficiente_de_z_e2.getText() + boton;
				 textfield_coeficiente_de_z_e2.setText(numeroIngresado);
				break;	 
			case "tie2":
				numeroIngresado = textfield_coeficiente_de_ti_e2.getText() + boton;
				textfield_coeficiente_de_ti_e2.setText(numeroIngresado);
				break;
			case "xe3":
				 numeroIngresado = textfield_coeficiente_de_x_e3.getText() + boton;
				 textfield_coeficiente_de_x_e3.setText(numeroIngresado);
				break;
			case "ye3":
				numeroIngresado = textfield_coeficiente_de_y_e3.getText() + boton;
				textfield_coeficiente_de_y_e3.setText(numeroIngresado);
				break;
			case "ze3":
				 numeroIngresado = textfield_coeficiente_de_z_e3.getText() + boton;
				 textfield_coeficiente_de_z_e3.setText(numeroIngresado);
				 break;
			case "tie3":
				numeroIngresado = textfield_coeficiente_de_ti_e3.getText() + boton;
				textfield_coeficiente_de_ti_e3.setText(numeroIngresado);
				break;
			}
		}
		else
		{
				switch(lastfocus)
				{
				case "xe1":
					numeroIngresado=textfield_coeficiente_de_x_e1.getText();
					textfield_coeficiente_de_x_e1.setText("-" + numeroIngresado);
					break;
				case "ye1":
					numeroIngresado=textfield_coeficiente_de_y_e1.getText();
					textfield_coeficiente_de_y_e1.setText("-" + numeroIngresado);
					break;
				case "ze1":
					numeroIngresado=textfield_coeficiente_de_z_e1.getText();
					textfield_coeficiente_de_z_e1.setText("-" + numeroIngresado);
					 break;
				case "tie1":
					numeroIngresado=textfield_coeficiente_de_ti_e1.getText();
					textfield_coeficiente_de_ti_e1.setText("-" + numeroIngresado);
					break;
				case "xe2":
					numeroIngresado=textfield_coeficiente_de_x_e2.getText();
					textfield_coeficiente_de_x_e2.setText("-" + numeroIngresado);
					break;
				case "ye2":
					numeroIngresado=textfield_coeficiente_de_y_e2.getText();
					textfield_coeficiente_de_y_e2.setText("-" + numeroIngresado);
					break;
				case "ze2":
					numeroIngresado=textfield_coeficiente_de_z_e2.getText();
					textfield_coeficiente_de_z_e2.setText("-" + numeroIngresado);
					break;	 
				case "tie2":
					numeroIngresado=textfield_coeficiente_de_ti_e2.getText();
					textfield_coeficiente_de_ti_e2.setText("-" + numeroIngresado);
					break;
				case "xe3":
					numeroIngresado=textfield_coeficiente_de_x_e3.getText();
					textfield_coeficiente_de_x_e3.setText("-" + numeroIngresado);
					break;
				case "ye3":
					numeroIngresado=textfield_coeficiente_de_y_e3.getText();
					textfield_coeficiente_de_y_e3.setText("-" + numeroIngresado);
					break;
				case "ze3":
					numeroIngresado=textfield_coeficiente_de_z_e3.getText();
					textfield_coeficiente_de_z_e3.setText("-" + numeroIngresado);
					 break;
				case "tie3":
					numeroIngresado=textfield_coeficiente_de_ti_e3.getText();
					textfield_coeficiente_de_ti_e3.setText("-" + numeroIngresado);
					break;
				}
		}
	}
	
	// Its use its only for deleting a character in the text field that the user wants
	private void del_button(JTextField text_field, String numeroIngresado)
	{
		 numeroIngresado = text_field.getText();
		 if (numeroIngresado.length() > 0) 
		 {
			 text_field.setText(numeroIngresado.substring(0, numeroIngresado.length() - 1));
        }
	}
	
	//Point verification
	private void point_verification(String last_focus)
	{
		switch(last_focus)
		{
			case "xe1":
				if(textfield_coeficiente_de_x_e1.getText().contains("."))
				{
					
					boton_decimal.setEnabled(false);
				}
				else
				{
					boton_decimal.setEnabled(true);
				}
				break;
			case "ye1":
				if(textfield_coeficiente_de_y_e1.getText().contains("."))
				{
					boton_decimal.setEnabled(false);
				}
				else
				{
					boton_decimal.setEnabled(true);
				}
				break;
			case "ze1":
				if(textfield_coeficiente_de_z_e1.getText().contains("."))
				{
					boton_decimal.setEnabled(false);
				}
				else
				{
					boton_decimal.setEnabled(true);
				}
				 break;
			case "tie1":
				if(textfield_coeficiente_de_ti_e1.getText().contains("."))
				{
					boton_decimal.setEnabled(false);
				}
				else
				{
					boton_decimal.setEnabled(true);
				}
				break;
			case "xe2":
				if(textfield_coeficiente_de_x_e2.getText().contains("."))
				{
					boton_decimal.setEnabled(false);
				}
				else
				{
					boton_decimal.setEnabled(true);
				}
				break;
			case "ye2":
				if(textfield_coeficiente_de_y_e2.getText().contains("."))
				{
					boton_decimal.setEnabled(false);
				}
				else
				{
					boton_decimal.setEnabled(true);
				}
				break;
			case "ze2":
				if(textfield_coeficiente_de_z_e2.getText().contains("."))
				{
					boton_decimal.setEnabled(false);
				}
				else
				{
					boton_decimal.setEnabled(true);
				}
				break;	 
			case "tie2":
				if(textfield_coeficiente_de_ti_e2.getText().contains("."))
				{
					boton_decimal.setEnabled(false);
				}
				else
				{
					boton_decimal.setEnabled(true);
				}
				break;
			case "xe3":
				if(textfield_coeficiente_de_x_e3.getText().contains("."))
				{
					boton_decimal.setEnabled(false);
				}
				else
				{
					boton_decimal.setEnabled(true);
				}
				break;
			case "ye3":
				if(textfield_coeficiente_de_y_e3.getText().contains("."))
				{
					boton_decimal.setEnabled(false);
				}
				else
				{
					boton_decimal.setEnabled(true);
				}
				break;
			case "ze3":
				if(textfield_coeficiente_de_z_e3.getText().contains("."))
				{
					boton_decimal.setEnabled(false);
				}
				else
				{
					boton_decimal.setEnabled(true);
				}
				 break;
			case "tie3":
				if(textfield_coeficiente_de_ti_e3.getText().contains("."))
				{
					boton_decimal.setEnabled(false);
				}
				else
				{
					boton_decimal.setEnabled(true);
				}
				break;
		}
	}
	
	//Change sign verification
	private void cambio_de_signo_verification(String last_focus)
	{
		switch(last_focus)
		{
			case "xe1":
					if(textfield_coeficiente_de_x_e1.getText().contains("-"))
					{
						boton_signo.setEnabled(false);
					}
					else
					{
						boton_signo.setEnabled(true);
					}
				break;
			case "ye1":
				if(textfield_coeficiente_de_y_e1.getText().contains("-"))
				{
					boton_signo.setEnabled(false);
				}
				else
				{
					boton_signo.setEnabled(true);
				}
				break;
			case "ze1":
				if(textfield_coeficiente_de_z_e1.getText().contains("-"))
				{
					boton_signo.setEnabled(false);
				}
				else
				{
					boton_signo.setEnabled(true);
				}
				 break;
			case "tie1":
				if(textfield_coeficiente_de_ti_e1.getText().contains("-"))
				{
					boton_signo.setEnabled(false);
				}
				else
				{
					boton_signo.setEnabled(true);
				}
				break;
			case "xe2":
				if(textfield_coeficiente_de_x_e2.getText().contains("-"))
				{
					boton_signo.setEnabled(false);
				}
				else
				{
					boton_signo.setEnabled(true);
				}
				break;
			case "ye2":
				if(textfield_coeficiente_de_y_e2.getText().contains("-"))
				{
					boton_signo.setEnabled(false);
				}
				else
				{
					boton_signo.setEnabled(true);
				}
				break;
			case "ze2":
				if(textfield_coeficiente_de_z_e2.getText().contains("-"))
				{
					boton_signo.setEnabled(false);
				}
				else
				{
					boton_signo.setEnabled(true);
				}
				break;	 
			case "tie2":
				if(textfield_coeficiente_de_ti_e2.getText().contains("-"))
				{
					boton_signo.setEnabled(false);
				}
				else
				{
					boton_signo.setEnabled(true);
				}
				break;
			case "xe3":
				if(textfield_coeficiente_de_x_e3.getText().contains("-"))
				{
					boton_signo.setEnabled(false);
				}
				else
				{
					boton_signo.setEnabled(true);
				}
				break;
			case "ye3":
				if(textfield_coeficiente_de_y_e3.getText().contains("-"))
				{
					boton_signo.setEnabled(false);
				}
				else
				{
					boton_signo.setEnabled(true);
				}
				break;
			case "ze3":
				if(textfield_coeficiente_de_z_e3.getText().contains("-"))
				{
					boton_signo.setEnabled(false);
				}
				else
				{
					boton_signo.setEnabled(true);
				}
				 break;
			case "tie3":
				if(textfield_coeficiente_de_ti_e3.getText().contains("-"))
				{
					boton_signo.setEnabled(false);
				}
				else
				{
					boton_signo.setEnabled(true);
				}
				break;
		}
	}
	
	// Text Field Verification
	private void text_field_verification(JTextField textfield)
	{
		try {
	        Float.parseFloat(textfield.getText());
	    } catch (NumberFormatException e) {
	        textfield_check = 1;
	    }
	}
	
	// Hover for the buttons 
	// Credits: Matias decurgez
	private void hover(JButton boton)
	{
		boton.setBorder(null);
		boton.setFocusPainted(false);
		Color normalColor = boton.getBackground();
		int rojo = normalColor.getRed();
		int verde = normalColor.getGreen();
		int azul = normalColor.getBlue();
		int rojoN = rojo + 20;
		int verdeN = verde + 20;
		int azulN = azul + 20;
		if(rojoN > 255)
		{
			rojoN = 255;
		}
		if(verdeN > 255)
		{
			verdeN = 255;
		}
		if(azulN > 255)
		{
			azulN = 255;
		}
		
        Color hoverColor = new Color(rojoN, verdeN, azulN);
        
        boton.addMouseListener(new MouseAdapter() 
        {
            Timer enterTimer;
            Timer exitTimer;

            public void mouseEntered(MouseEvent e) 
            {
                if (exitTimer != null && exitTimer.isRunning())
                {
                    exitTimer.stop();
                }
                enterTimer = createColorTransitionTimer(boton, normalColor, hoverColor);
                enterTimer.start();
            }

            public void mouseExited(MouseEvent e) 
            {
                if (enterTimer != null && enterTimer.isRunning()) 
                {
                    enterTimer.stop();
                }
                exitTimer = createColorTransitionTimer(boton, hoverColor, normalColor);
                exitTimer.start();
            }
        });
	}
	
	private static Timer createColorTransitionTimer(JButton button, Color startColor, Color endColor) 
	{
        return new Timer(ANIMATION_DELAY, null) 
        {
			/**
			 * 
			 */
			private static final long serialVersionUID = -5655110578704348705L;
			long startTime = System.currentTimeMillis();
            {
                addActionListener(e -> {
                    long elapsed = System.currentTimeMillis() - startTime;
                    float progress = Math.min(1.0f, (float) elapsed / ANIMATION_DURATION);
                    button.setBackground(interpolateColor(startColor, endColor, progress));
                    if (progress >= 1.0f) {
                        ((Timer) e.getSource()).stop();
                    }
                });
            }
        };
    }

    private static Color interpolateColor(Color startColor, Color endColor, float fraction) 
    {
        int red = (int) (startColor.getRed() + (endColor.getRed() - startColor.getRed()) * fraction);
        int green = (int) (startColor.getGreen() + (endColor.getGreen() - startColor.getGreen()) * fraction);
        int blue = (int) (startColor.getBlue() + (endColor.getBlue() - startColor.getBlue()) * fraction);
        return new Color(red, green, blue);
    } 
}