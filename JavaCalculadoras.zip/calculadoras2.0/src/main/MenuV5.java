package main;

import gui.VentanaV5;

public class MenuV5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			presentarventana();
	}
	
	private static void presentarventana()
	{
		VentanaV5 miVentana =new VentanaV5();
		miVentana.setVisible(true);
	}
}