package main;
import gui.VentanaV5;
import gui.Panel;
import gui.VectoresMain;
import gui.Calculador_a;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.Timer;

import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class mainVentana extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	VentanaV5 ventanaSistEcuaciones = new VentanaV5();
	VectoresMain ventanaVectores = new VectoresMain();
	Panel ventanaMatrices = new Panel();
	Calculador_a ventanaEstandar = new Calculador_a();
	private static final int ANIMATION_DURATION = 250; // Duración de la animación en milisegundos
    private static final int ANIMATION_DELAY = 20; // Retraso entre cada paso de la animación en milisegundos

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainVentana frame = new mainVentana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public mainVentana() {
		ventanaEstandar.setVisible(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 700);
		setResizable(false);
		setFont(new Font("Segoe UI", Font.PLAIN, 20));
		setTitle("Calculadoras");
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(51, 51, 51));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panelTitulo = new JPanel();
		panelTitulo.setBackground(new Color(51, 51, 51));
		panelTitulo.setBounds(10, 11, 564, 80);
		contentPane.add(panelTitulo);
		panelTitulo.setLayout(null);
		
		JLabel lblTitulo = new JLabel("Calculadoras");
		lblTitulo.setBackground(new Color(51, 51, 51));
		lblTitulo.setForeground(new Color(255, 255, 255));
		lblTitulo.setBounds(10, 11, 544, 58);
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 40));
		panelTitulo.add(lblTitulo);
		
		JPanel panelPrincipal = new JPanel();
		panelPrincipal.setBackground(new Color(51, 51, 51));
		panelPrincipal.setBounds(42, 101, 500, 500);
		contentPane.add(panelPrincipal);
		panelPrincipal.setLayout(null);
		
		JPanel panelBotones = new JPanel();
		panelBotones.setBackground(new Color(51, 51, 51));
		panelBotones.setBounds(10, 11, 480, 478);
		panelPrincipal.add(panelBotones);
		panelBotones.setLayout(new GridLayout(4, 1, 5, 5));
		
		JButton btnEstandar = new JButton("Estándar");
		btnEstandar.setForeground(new Color(255, 255, 255));
		btnEstandar.setBackground(new Color(0, 150, 255));
		btnEstandar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ventanaEstandar.setVisible(true);
			}
		});
		btnEstandar.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		panelBotones.add(btnEstandar);
		hover(btnEstandar);
		
		JButton btnVectores = new JButton("Vectores");
		btnVectores.setForeground(new Color(255, 255, 255));
		btnVectores.setBackground(new Color(0, 150, 255));
		btnVectores.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		panelBotones.add(btnVectores);
		btnVectores.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ventanaVectores.setVisible(true);
			}
		});
		hover(btnVectores);
		
		JButton btnMatrices = new JButton("Matrices");
		btnMatrices.setForeground(new Color(255, 255, 255));
		btnMatrices.setBackground(new Color(0, 150, 255));
		btnMatrices.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ventanaMatrices.setVisible(true);
			}
		});
		btnMatrices.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		panelBotones.add(btnMatrices);
		hover(btnMatrices);
		
		JButton btnSistemaEcuac = new JButton("Sistema de Ecuaciones");
		btnSistemaEcuac.setForeground(new Color(255, 255, 255));
		btnSistemaEcuac.setBackground(new Color(0, 150, 255));
		btnSistemaEcuac.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ventanaSistEcuaciones.setVisible(true);
			}
		});
		btnSistemaEcuac.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		panelBotones.add(btnSistemaEcuac);
		hover(btnSistemaEcuac);
		
		JPanel panelCreditos = new JPanel();
		panelCreditos.setBackground(new Color(51, 51, 51));
		panelCreditos.setBounds(42, 612, 500, 38);
		contentPane.add(panelCreditos);
		panelCreditos.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("©Patricio Sarale, Matías Decurgez, Francisco Sosa, Tiziano Roberti");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel.setBackground(new Color(51, 51, 51));
		lblNewLabel.setBounds(0, 0, 500, 38);
		panelCreditos.add(lblNewLabel);
	}
	private void hover(JButton boton)
	{
		boton.setBorder(null);
		boton.setFocusPainted(false);
		Color normalColor = boton.getBackground();
		int rojo = normalColor.getRed();
		int verde = normalColor.getGreen();
		int azul = normalColor.getBlue();
		int rojoN = rojo + 30;
		int verdeN = verde + 30;
		int azulN = azul + 30;
		if(rojoN > 255)
		{
			rojoN = 255;
		}
		if(verdeN > 255)
		{
			verdeN = 255;
		}
		if(azulN > 255)
		{
			azulN = 255;
		}
		
        Color hoverColor = new Color(rojoN, verdeN, azulN);
        
    	boton.addMouseListener(new MouseAdapter() {
            Timer enterTimer;
            Timer exitTimer;

            public void mouseEntered(MouseEvent e) {
                if (exitTimer != null && exitTimer.isRunning()) {
                    exitTimer.stop();
                }
                enterTimer = createColorTransitionTimer(boton, normalColor, hoverColor);
                enterTimer.start();
            }

            public void mouseExited(MouseEvent e) {
                if (enterTimer != null && enterTimer.isRunning()) {
                    enterTimer.stop();
                }
                exitTimer = createColorTransitionTimer(boton, hoverColor, normalColor);
                exitTimer.start();
            }
    	});
	}
	private static Timer createColorTransitionTimer(JButton button, Color startColor, Color endColor) {
        return new Timer(ANIMATION_DELAY, null) {
			private static final long serialVersionUID = -4701965186790357155L;
			long startTime = System.currentTimeMillis();

            {
                addActionListener(e -> {
                    long elapsed = System.currentTimeMillis() - startTime;
                    float progress = Math.min(1.0f, (float) elapsed / ANIMATION_DURATION);
                    button.setBackground(interpolateColor(startColor, endColor, progress));
                    if (progress >= 1.0f) {
                        ((Timer) e.getSource()).stop();
                    }
                });
            }
        };
    }

    private static Color interpolateColor(Color startColor, Color endColor, float fraction) {
        int red = (int) (startColor.getRed() + (endColor.getRed() - startColor.getRed()) * fraction);
        int green = (int) (startColor.getGreen() + (endColor.getGreen() - startColor.getGreen()) * fraction);
        int blue = (int) (startColor.getBlue() + (endColor.getBlue() - startColor.getBlue()) * fraction);
        return new Color(red, green, blue);
    }
}
